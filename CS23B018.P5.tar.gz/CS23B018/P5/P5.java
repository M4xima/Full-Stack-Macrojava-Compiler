import java.util.*;
import syntaxtree.*;
import visitor.*;
   

public class P5 {
   public static void main(String [] args) {
      try {
         Node root = new microIRParser(System.in).Goal();

         MicroIRtoMiniRA0 parser0 = new MicroIRtoMiniRA0();
         root.accept(parser0, null); // Your assignment part is invoked here.

         Map<String, Map<String, Integer>> LabMap = parser0.LabMap;
         MicroIRtoMiniRA1 parser1 = new MicroIRtoMiniRA1(LabMap);
         root.accept(parser1, null); // Your assignment part is invoked here.

         Map<String, Set<String>> spilledTemps = parser1.spilledTemps;
         Map<String, Map<String, interval>> tempLines = parser1.tempLines;
         Map<String, List<Integer>> noOfArg = parser0.noOfArg;
         MicroIRtoMiniRA2 parser2 = new MicroIRtoMiniRA2(spilledTemps, tempLines, noOfArg);
         root.accept(parser2, null); // Your assignment part is invoked here.
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
} 


