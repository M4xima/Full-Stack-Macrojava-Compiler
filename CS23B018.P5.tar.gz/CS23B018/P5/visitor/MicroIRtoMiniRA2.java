package visitor;
import java.util.*;
import syntaxtree.*;

public class MicroIRtoMiniRA2 implements GJVisitor<String, String> {
    //
    // Auto class visitors--probably don't need to be overridden.
    //
      Map<String, List<Integer>> noOfArg = new HashMap<>();//0 is number of args, 1 is total stack space used, 2 is maximum no of args in calls
      Map<String, Set<String>> spilledTemps = new HashMap<>();
      Map<String, Map<String, interval>> tempLines = new HashMap<>();
      String curProc = null;
      String curSpilledTemp = null;
      Map<String, Map<String, Integer>> tempToNum = new HashMap<>();
      Map<String, Integer> tempNum = new HashMap<>();
      public MicroIRtoMiniRA2(Map<String, Set<String>> spilledTemps, Map<String, Map<String, interval>> tempLines, Map<String, List<Integer>> noOfArg){ 
         this.spilledTemps = spilledTemps;
         this.tempLines = tempLines;
         this.noOfArg = noOfArg;
      }
    public String visit(NodeList n, String argu) {
       String _ret = "";
       int _count=0;
       for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
          _ret += e.nextElement().accept(this,argu) + " ";
          _count++;
       }
       return _ret + "\n";
    }
 
    public String visit(NodeListOptional n, String argu) {
       if ( n.present() ) {
         String _ret = "";
          int _count=0;
          for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
            _ret += e.nextElement().accept(this,argu) + " ";
             _count++;
          }
          return _ret + "\n";
       }
       else
          return "";
    }
 
    public String visit(NodeOptional n, String argu) {
       if ( n.present() )
          return n.node.accept(this,argu);
       else
          return "";
    }
 
    public String visit(NodeSequence n, String argu) {
      String _ret = "";
       int _count=0;
       for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
          _ret += e.nextElement().accept(this,argu) + " ";
          _count++;
       }
       return _ret + "\n";
    }
 
    public String visit(NodeToken n, String argu) { return n.tokenImage; }
 
    //
    // User-generated visitor methods below
    //
 
    /**
     * f0 -> "MAIN"
     * f1 -> StmtList()
     * f2 -> "END"
     * f3 -> ( Procedure() )*
     * f4 -> <EOF>
     */
    public String visit(Goal n, String argu) {
       String _ret = "";
       curProc = "MAIN";
       tempToNum.put(curProc, new HashMap<>());
       int startpoint = noOfArg.get(curProc).get(0) - 4;
       if(startpoint < 0) startpoint = 0;
       tempNum.put(curProc, startpoint + 8);
       _ret += "MAIN [0] [" + (noOfArg.get(curProc).get(1)  + spilledTemps.get(curProc).size()) + "] [" + noOfArg.get(curProc).get(2) + "]\n";
       _ret += n.f1.accept(this, argu);
       _ret += "END\n";
       if(spilledTemps.get(curProc).size() > 0)_ret += "//SPILLED\n";
       else _ret += "//NOT SPILLED\n";
       _ret += "\n";
       _ret += n.f3.accept(this, argu);
       n.f4.accept(this, argu);
       System.out.println(_ret);
       return _ret;
    }
 
    /**
     * f0 -> ( ( Label() )? Stmt() )*
     */
    public String visit(StmtList n, String argu) {
      String _ret = "";
      for (Node node : n.f0.nodes) {
         NodeSequence seq = (NodeSequence) node;
         NodeOptional optLabel = (NodeOptional) seq.elementAt(0);
         if (optLabel.present()) {
             Label label = (Label) optLabel.node;
             String labelName = label.f0.tokenImage;
             _ret += labelName + " ";
         }
         Stmt stmt = (Stmt) seq.elementAt(1);
         _ret += stmt.accept(this, argu);  
     }
      return _ret;
    }
 
    /**
     * f0 -> Label()
     * f1 -> "["
     * f2 -> IntegerLiteral()
     * f3 -> "]"
     * f4 -> StmtExp()
     */
    public String visit(Procedure n, String argu) {
       String _ret = "";
       curProc = n.f0.accept(this, argu);
      //  System.out.println(curProc + "\n");
       tempToNum.put(curProc, new HashMap<>());
       int startpoint = noOfArg.get(curProc).get(0) - 4;
       if(startpoint < 0) startpoint = 0;
       tempNum.put(curProc, startpoint + 8);
       _ret += curProc + " [" + n.f2.accept(this, argu) + "] [" + (noOfArg.get(curProc).get(1) + spilledTemps.get(curProc).size())+ "] [" + noOfArg.get(curProc).get(2) + "]\n";
       _ret += n.f4.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> NoOpStmt()
     *       | ErrorStmt()
     *       | CJumpStmt()
     *       | JumpStmt()
     *       | HStoreStmt()
     *       | HLoadStmt()
     *       | MoveStmt()
     *       | PrintStmt()
     */
    public String visit(Stmt n, String argu) {
       String _ret = n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> "NOOP"
     */
    public String visit(NoOpStmt n, String argu) {
       return "NOOP\n";
    }
 
    /**
     * f0 -> "ERROR"
     */
    public String visit(ErrorStmt n, String argu) {
       return "ERROR\n";
    }
 
    /**
     * f0 -> "CJUMP"
     * f1 -> Temp()
     * f2 -> Label()
     */
    public String visit(CJumpStmt n, String argu) {
       String _ret = "";
       if(n.f1.accept(this, argu).equals("spilled")){
         _ret += "ALOAD v0 SLPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
       }
       _ret += "CJUMP ";
       if(n.f1.accept(this, argu).equals("spilled"))_ret += "v0 ";
       else _ret += n.f1.accept(this, argu) + " ";
       _ret += n.f2.accept(this, argu) + "\n";
       return _ret;
    }
 
    /**
     * f0 -> "JUMP"
     * f1 -> Label()
     */
    public String visit(JumpStmt n, String argu) {
       String _ret = "";
       _ret += "JUMP ";
       _ret += n.f1.accept(this, argu) + "\n";
       return _ret;
    }
 
    /**
     * f0 -> "HSTORE"
     * f1 -> Temp()
     * f2 -> IntegerLiteral()
     * f3 -> Temp()
     */
    public String visit(HStoreStmt n, String argu) {
       String _ret = "";
       if(n.f1.accept(this, argu).equals("spilled")){
         _ret += "ALOAD v0 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
       }
       if(n.f3.accept(this, argu).equals("spilled")){
         _ret += "ALOAD v1 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
       }
         _ret += "HSTORE ";
         if(n.f1.accept(this, argu).equals("spilled"))_ret += "v0 ";
         else _ret += n.f1.accept(this, argu) + " ";
         _ret += n.f2.accept(this, argu) + " ";
         if(n.f3.accept(this, argu).equals("spilled"))_ret += "v1\n";
         else _ret += n.f3.accept(this, argu) + "\n";
       return _ret;
    }
 
    /**
     * f0 -> "HLOAD"
     * f1 -> Temp()
     * f2 -> Temp()
     * f3 -> IntegerLiteral()
     */
    public String visit(HLoadStmt n, String argu) {
       String _ret = "";
         if(n.f2.accept(this, argu).equals("spilled")){
             _ret += "ALOAD v0 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
         }
         _ret += "HLOAD ";
         if(n.f1.accept(this, argu).equals("spilled"))_ret += "v0 ";
         else _ret += n.f1.accept(this, argu) + " ";
         if(n.f2.accept(this, argu).equals("spilled"))_ret += "v0 ";
         else _ret += n.f2.accept(this, argu) + " ";
         _ret += n.f3.accept(this, argu) + "\n";
         if(n.f1.accept(this, argu).equals("spilled")){
            _ret += "ASTORE SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + " v0\n";
         }
       return _ret;
    }
 
    /**
     * f0 -> "MOVE"
     * f1 -> Temp()
     * f2 -> Exp()
     */
    public String visit(MoveStmt n, String argu) {
      if(n.f2.f0.which == 0){
         String _ret = "";
         _ret += n.f2.accept(this, argu);
         _ret += "MOVE ";
         if(n.f1.accept(this, argu).equals("spilled")){
            _ret += "v1 v0\n";
            _ret += "ASTORE SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + " v1\n";
         }   
         else _ret += n.f1.accept(this, argu) + " v0\n";
         return _ret;
      }
       String _ret = "";
         _ret += n.f2.accept(this, argu) + "\n";
         _ret += "MOVE ";
         if(n.f1.accept(this, argu).equals("spilled")){
            _ret += "v1 v0\n";
            _ret += "ASTORE SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + " v1\n";
         }   
         else _ret += n.f1.accept(this, argu) + " v0\n";
       return _ret;
    }
 
    /**
     * f0 -> "PRINT"
     * f1 -> SimpleExp()
     */
    public String visit(PrintStmt n, String argu) {
       String _ret = "";
       if(n.f1.accept(this, argu).equals("spilled")){
         _ret += "ALOAD v0 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
       }
         _ret += "PRINT ";
         if(n.f1.accept(this, argu).equals("spilled"))_ret += "v0\n";
         else _ret += n.f1.accept(this, argu) + "\n";
       return _ret;
    }
 
    /**
     * f0 -> Call()
     *       | HAllocate()
     *       | BinOp()
     *       | SimpleExp()
     */
    public String visit(Exp n, String argu) {
       String _ret = "";
       if(n.f0.which == 3){
         if(n.f0.accept(this, null).equals("spilled")){
            _ret += "ALOAD v0 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
         }
         _ret += "MOVE v0 " + n.f0.accept(this, argu) + "\n";
       }
       else _ret = n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> "BEGIN"
     * f1 -> StmtList()
     * f2 -> "RETURN"
     * f3 -> SimpleExp()
     * f4 -> "END"
     */
    public String visit(StmtExp n, String argu) {
       String _ret = "";
       int startpoint = noOfArg.get(curProc).get(0) - 4;
       if(startpoint < 0) startpoint = 0;
         _ret += preFun(startpoint);
         for(int i = 0;i < noOfArg.get(curProc).get(0);i ++){
            if(tempLines.get(curProc).get("TEMP " + i) == null) continue;
            if(i <= 3)_ret += "MOVE " + getRegister(tempLines.get(curProc).get("TEMP " + i).color) + " a" + i + "\n";
            else _ret += "ALOAD " + getRegister(tempLines.get(curProc).get("TEMP " + i).color) + " SPILLEDARG " + (i - 4) + "\n";
         }
         _ret += n.f1.accept(this, argu);
         if(n.f3.accept(this, argu).equals("spilled")){
           _ret += "ALOAD v0 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
         }
         else _ret += "MOVE v0 " + n.f3.accept(this, argu) + "\n";
         _ret += postFun(startpoint);
         _ret += "END\n";
         if(!spilledTemps.get(curProc).isEmpty())_ret += "//SPILLED\n";
         else _ret += "//NOT SPILLED\n";
         _ret += "\n";
       return _ret;
    }
 
    /**
     * f0 -> "CALL"
     * f1 -> SimpleExp()
     * f2 -> "("
     * f3 -> ( Temp() )*
     * f4 -> ")"
     */
    public String visit(Call n, String argu) {
      String _ret = "";
      int startpoint = noOfArg.get(curProc).get(0) - 4;
      if(startpoint < 0) startpoint = 0;
      if(curProc != "MAIN")_ret += prologue(startpoint + 8);
      else _ret += prologue(startpoint);
      if ( n.f3.present() ) {
          int _count=0;
          for ( Enumeration<Node> e = n.f3.elements(); e.hasMoreElements(); ) {
            if(_count <= 3){
               String temp = e.nextElement().accept(this,argu);
               if(temp.equals("spilled")){
                  _ret += "ALOAD v0 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
                  _ret += "MOVE a" + _count + " v0\n";
               }
               else _ret += "MOVE a" + _count + " " + temp + "\n";
            }
            else{
               String temp = e.nextElement().accept(this,argu);
               if(temp.equals("spilled")){
                  _ret += "ALOAD v0 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
                  _ret += "PASSARG " + (_count - 3) + " v0\n";
               }
               else _ret += "PASSARG " + (_count - 3) + " " + temp + "\n";
            }
             _count++;
          }
       }
       else _ret += "";
       if(n.f1.accept(this, argu).equals("spilled")){
         _ret += "ALOAD v0 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
         _ret += "CALL v0\n";
       }
      else _ret += "CALL " + n.f1.accept(this, argu) + "\n";
      if(curProc != "MAIN")_ret += epilogue(startpoint + 8);
      else _ret += epilogue(startpoint);
      return _ret;
    }
 
    /**
     * f0 -> "HALLOCATE"
     * f1 -> SimpleExp()
     */
    public String visit(HAllocate n, String argu) {
       String _ret = "";
       if(n.f1.accept(this, argu).equals("spilled")){
         _ret += "ALOAD v0 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
       }
      else _ret += "MOVE v0 " + n.f1.accept(this, argu) + "\n";
         _ret += "MOVE v1 PLUS v0 4\n";
         _ret += "MOVE v0 HALLOCATE v1\n";
       return _ret;
    }
 
    /**
     * f0 -> Operator()
     * f1 -> Temp()
     * f2 -> SimpleExp()
     */
    public String visit(BinOp n, String argu) {
       String _ret = "";
         if(n.f1.accept(this, argu).equals("spilled")){
             _ret += "ALOAD v0 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
         }
         if(n.f2.accept(this, argu).equals("spilled")){
             _ret += "ALOAD v1 SPILLEDARG " + tempToNum.get(curProc).get(curSpilledTemp) + "\n";
         }
         _ret += "MOVE v0 ";
         _ret += n.f0.accept(this, argu) + " ";
         if(n.f1.accept(this, argu).equals("spilled"))_ret += "v0 ";
         else _ret += n.f1.accept(this, argu) + " ";
         if(n.f2.accept(this, argu).equals("spilled"))_ret += "v1";
         else _ret += n.f2.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> "LE"
     *       | "NE"
     *       | "PLUS"
     *       | "MINUS"
     *       | "TIMES"
     *       | "DIV"
     */
    public String visit(Operator n, String argu) {
       String _ret = n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> Temp()
     *       | IntegerLiteral()
     *       | Label()
     */
    public String visit(SimpleExp n, String argu) {
       String _ret = n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> "TEMP"
     * f1 -> IntegerLiteral()
     */
    public String visit(Temp n, String argu) {
       String _ret = "";
      //  System.out.println(curProc + ": TEMP " + n.f1.accept(this, argu) + "\n" );
      //  System.out.println("color: " + tempLines.get(curProc).get("TEMP " + n.f1.accept(this, argu)).color + "\n");
       _ret = getRegister(tempLines.get(curProc).get("TEMP " + n.f1.accept(this, argu)).color);
       if(_ret == "spilled"){
         curSpilledTemp = "TEMP " + n.f1.accept(this, argu);
         if(tempToNum.get(curProc).get(curSpilledTemp) == null){
            int num = tempNum.get(curProc);
            tempToNum.get(curProc).put(curSpilledTemp, num);
            tempNum.put(curProc, num + 1);
         }
       }
       return _ret;
    }
 
    /**
     * f0 -> <INTEGER_LITERAL>
     */
    public String visit(IntegerLiteral n, String argu) {
       String _ret = n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> <IDENTIFIER>
     */
    public String visit(Label n, String argu) {
       String _ret = n.f0.accept(this, argu);
       return _ret;
    }
    String getRegister(int num){
         switch(num){
            case 0: return "s0";
            case 1: return "s1";
            case 2: return "s2";
            case 3: return "s3";
            case 4: return "s4";
            case 5: return "s5";
            case 6: return "s6";
            case 7: return "s7";
            case 8: return "t0";
            case 9: return "t1";
            case 10: return "t2";
            case 11: return "t3";
            case 12: return "t4";
            case 13: return "t5";
            case 14: return "t6";
            case 15: return "t7";
            case 16: return "t8";
            case 17: return "t9";
            default: return "spilled";
         }
    }
    String prologue(int i){
      String _ret = "";
      _ret += "ASTORE SPILLEDARG " + i + " t0\n";
      _ret += "ASTORE SPILLEDARG " + (i + 1)+ " t1\n";
      _ret += "ASTORE SPILLEDARG " + (i + 2)+ " t2\n";
      _ret += "ASTORE SPILLEDARG " + (i + 3)+ " t3\n";
      _ret += "ASTORE SPILLEDARG " + (i + 4)+ " t4\n";
      _ret += "ASTORE SPILLEDARG " + (i + 5)+ " t5\n";
      _ret += "ASTORE SPILLEDARG " + (i + 6)+ " t6\n";
      _ret += "ASTORE SPILLEDARG " + (i + 7)+ " t7\n";
      _ret += "ASTORE SPILLEDARG " + (i + 8)+ " t8\n";
      _ret += "ASTORE SPILLEDARG " + (i + 9)+ " t9\n";
      return _ret;
    }
    String epilogue(int i){
      String _ret = "";
      _ret += "ALOAD t0 SPILLEDARG " + i + "\n";
      _ret += "ALOAD t1 SPILLEDARG " + (i + 1)+ "\n";
      _ret += "ALOAD t2 SPILLEDARG " + (i + 2)+ "\n";
      _ret += "ALOAD t3 SPILLEDARG " + (i + 3)+ "\n";
      _ret += "ALOAD t4 SPILLEDARG " + (i + 4)+ "\n";
      _ret += "ALOAD t5 SPILLEDARG " + (i + 5)+ "\n";
      _ret += "ALOAD t6 SPILLEDARG " + (i + 6)+ "\n";
      _ret += "ALOAD t7 SPILLEDARG " + (i + 7)+ "\n";
      _ret += "ALOAD t8 SPILLEDARG " + (i + 8)+ "\n";
      _ret += "ALOAD t9 SPILLEDARG " + (i + 9)+ "\n";
      return _ret;
    }
    String preFun(int i){
      String _ret = "";
      _ret += "ASTORE SPILLEDARG " + i + " s0 \n";
      _ret += "ASTORE SPILLEDARG " + (i + 1) + " s1\n";
      _ret += "ASTORE SPILLEDARG " + (i + 2) + " s2\n";
      _ret += "ASTORE SPILLEDARG " + (i + 3) + " s3\n";
      _ret += "ASTORE SPILLEDARG " + (i + 4) + " s4\n";
      _ret += "ASTORE SPILLEDARG " + (i + 5) + " s5\n";
      _ret += "ASTORE SPILLEDARG " + (i + 6) + " s6\n";
      _ret += "ASTORE SPILLEDARG " + (i + 7) + " s7\n";
      return _ret;
    }
    String postFun(int i){
      String _ret = "";
      _ret += "ALOAD s0 SPILLEDARG " + i + "\n";
      _ret += "ALOAD s1 SPILLEDARG " + (i + 1)+ "\n";
      _ret += "ALOAD s2 SPILLEDARG " + (i + 2)+ "\n";
      _ret += "ALOAD s3 SPILLEDARG " + (i + 3)+ "\n";
      _ret += "ALOAD s4 SPILLEDARG " + (i + 4)+ "\n";
      _ret += "ALOAD s5 SPILLEDARG " + (i + 5)+ "\n";
      _ret += "ALOAD s6 SPILLEDARG " + (i + 6)+ "\n";
      _ret += "ALOAD s7 SPILLEDARG " + (i + 7)+ "\n";
      return _ret;
    }
 
 }
 