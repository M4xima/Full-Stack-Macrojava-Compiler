package visitor;
import java.util.*;
import syntaxtree.*;

public class MicroIRtoMiniRA0 implements GJVisitor<String, String> {
    //
    // Auto class visitors--probably don't need to be overridden.
    //
    public Map<String, List<Integer>> noOfArg = new HashMap<>();
    Map<String, Set<String>> usedFuns = new HashMap<>();
    public Map<String, Map<String, Integer>> LabMap = new HashMap<>();
    int curLine = 1;
    String curProc = null;
    Map<String, Integer> noOfFnCalls = new HashMap<>();
    void findnoOfArg() {
      for (String proc : usedFuns.keySet()) {
         int totalcalls = noOfFnCalls.get(proc);
         int otherfncalls = usedFuns.get(proc).size();
         if(totalcalls != otherfncalls)usedFuns.get(proc).add(proc);
      }
      for (String proc : usedFuns.keySet()) {
         int startpoint = noOfArg.get(curProc).get(0) - 4;
         if(startpoint < 0) startpoint = 0;
         if(!usedFuns.get(proc).isEmpty()){
            if(proc != "MAIN")noOfArg.get(proc).add(startpoint + 18);
            else noOfArg.get(proc).add(startpoint + 10);
         }
         else{
            if(proc != "MAIN")noOfArg.get(proc).add(startpoint + 8);
            else noOfArg.get(proc).add(startpoint);
         }
      }

      for (String proc : usedFuns.keySet()) {
         int temp = 0;
         for (String fn : usedFuns.get(proc)) {
            if(noOfArg.get(fn).get(0) > temp) {
               temp = noOfArg.get(fn).get(0);
            }
         }
         noOfArg.get(proc).add(temp);
      }
    }
    public String visit(NodeList n, String argu) {
       String _ret=null;
       int _count=0;
       for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
          e.nextElement().accept(this,argu);
          _count++;
       }
       return _ret;
    }
 
    public String visit(NodeListOptional n, String argu) {
       if ( n.present() ) {
          String _ret=null;
          int _count=0;
          for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
             e.nextElement().accept(this,argu);
             _count++;
          }
          return _ret;
       }
       else
          return null;
    }
 
    public String visit(NodeOptional n, String argu) {
       if ( n.present() )
          return n.node.accept(this,argu);
       else
          return null;
    }
 
    public String visit(NodeSequence n, String argu) {
       String _ret=null;
       int _count=0;
       for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
          e.nextElement().accept(this,argu);
          _count++;
       }
       return _ret;
    }
 
    public String visit(NodeToken n, String argu) { return n.tokenImage; }

 
    //
    // User-generated visitor methods below
    //
 
    /**
     * f0 -> "MAIN"
     * f1 -> StmtList()
     * f2 -> "END"
     * f3 -> ( Procedure() )*
     * f4 -> <EOF>
     */
    public String visit(Goal n, String argu) {
       String _ret=null;
       curProc = "MAIN";
       LabMap.put(curProc, new HashMap<String, Integer>());
       noOfArg.put(curProc, new ArrayList<>());
       noOfArg.get(curProc).add(0);
       usedFuns.put(curProc, new HashSet<>());
       noOfFnCalls.put(curProc, 0);
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
       n.f2.accept(this, argu);
       n.f3.accept(this, argu);
       findnoOfArg();
      //  System.out.println(noOfArg);
      //  System.out.println(usedFuns);
       n.f4.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> ( ( Label() )? Stmt() )*
     */
    public String visit(StmtList n, String argu) {
      for (Node node : n.f0.nodes) {
         NodeSequence seq = (NodeSequence) node;
         NodeOptional optLabel = (NodeOptional) seq.elementAt(0);
         if (optLabel.present()) {
             Label label = (Label) optLabel.node;
             String labelName = label.f0.tokenImage;
             LabMap.get(curProc).put(labelName, curLine);
         }
         Stmt stmt = (Stmt) seq.elementAt(1);
         stmt.accept(this, argu);  // process statement normally
     }
      return null;
    }
 
    /**
     * f0 -> Label()
     * f1 -> "["
     * f2 -> IntegerLiteral()
     * f3 -> "]"
     * f4 -> StmtExp()
     */
    public String visit(Procedure n, String argu) {
       String _ret=null;
       curProc = n.f0.accept(this, argu);
       LabMap.put(curProc, new HashMap<String, Integer>());
       n.f1.accept(this, argu);
       int arg1 = Integer.parseInt(n.f2.accept(this, argu));
       noOfArg.put(curProc, new ArrayList<>());
       noOfArg.get(curProc).add(arg1);
       usedFuns.put(curProc, new HashSet<>());
       noOfFnCalls.put(curProc, 0);
       n.f3.accept(this, argu);
       curLine = 1;
       n.f4.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> NoOpStmt()
     *       | ErrorStmt()
     *       | CJumpStmt()
     *       | JumpStmt()
     *       | HStoreStmt()
     *       | HLoadStmt()
     *       | MoveStmt()
     *       | PrintStmt()
     */
    public String visit(Stmt n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> "NOOP"
     */
    public String visit(NoOpStmt n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       curLine++;
       return _ret;
    }
 
    /**
     * f0 -> "ERROR"
     */
    public String visit(ErrorStmt n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
         curLine++;
       return _ret;
    }
 
    /**
     * f0 -> "CJUMP"
     * f1 -> Temp()
     * f2 -> Label()
     */
    public String visit(CJumpStmt n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
       n.f2.accept(this, argu);
       curLine++;
       return _ret;
    }
 
    /**
     * f0 -> "JUMP"
     * f1 -> Label()
     */
    public String visit(JumpStmt n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
         curLine++;
       return _ret;
    }
 
    /**
     * f0 -> "HSTORE"
     * f1 -> Temp()
     * f2 -> IntegerLiteral()
     * f3 -> Temp()
     */
    public String visit(HStoreStmt n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
       n.f2.accept(this, argu);
       n.f3.accept(this, argu);
         curLine++;
       return _ret;
    }
 
    /**
     * f0 -> "HLOAD"
     * f1 -> Temp()
     * f2 -> Temp()
     * f3 -> IntegerLiteral()
     */
    public String visit(HLoadStmt n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
       n.f2.accept(this, argu);
       n.f3.accept(this, argu);
         curLine++;
       return _ret;
    }
 
    /**
     * f0 -> "MOVE"
     * f1 -> Temp()
     * f2 -> Exp()
     */
    public String visit(MoveStmt n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
       n.f2.accept(this, argu);
       if(n.f2.f0.which == 3) { // SimpleExp
          String fnName = n.f2.f0.accept(this, argu);
          if(fnName != null)usedFuns.get(curProc).add(fnName);
       }
       curLine++;
       return _ret;
    }
 
    /**
     * f0 -> "PRINT"
     * f1 -> SimpleExp()
     */
    public String visit(PrintStmt n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
         curLine++;
       return _ret;
    }
 
    /**
     * f0 -> Call()
     *       | HAllocate()
     *       | BinOp()
     *       | SimpleExp()
     */
    public String visit(Exp n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> "BEGIN"
     * f1 -> StmtList()
     * f2 -> "RETURN"
     * f3 -> SimpleExp()
     * f4 -> "END"
     */
    public String visit(StmtExp n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
       n.f2.accept(this, argu);
       n.f3.accept(this, argu);
       n.f4.accept(this, argu);
       curLine++;
       return _ret;
    }
 
    /**
     * f0 -> "CALL"
     * f1 -> SimpleExp()
     * f2 -> "("
     * f3 -> ( Temp() )*
     * f4 -> ")"
     */
    public String visit(Call n, String argu) {
       String _ret=null;
       noOfFnCalls.put(curProc, noOfFnCalls.get(curProc) + 1);
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
       n.f2.accept(this, argu);
       n.f3.accept(this, argu);
       n.f4.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> "HALLOCATE"
     * f1 -> SimpleExp()
     */
    public String visit(HAllocate n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> Operator()
     * f1 -> Temp()
     * f2 -> SimpleExp()
     */
    public String visit(BinOp n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
       n.f2.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> "LE"
     *       | "NE"
     *       | "PLUS"
     *       | "MINUS"
     *       | "TIMES"
     *       | "DIV"
     */
    public String visit(Operator n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> Temp()
     *       | IntegerLiteral()
     *       | Label()
     */
    public String visit(SimpleExp n, String argu) {
      if(n.f0.which == 2) return n.f0.accept(this, argu);
      else return null;
    }
 
    /**
     * f0 -> "TEMP"
     * f1 -> IntegerLiteral()
     */
    public String visit(Temp n, String argu) {
      String _ret = "TEMP " + n.f1.accept(this, argu);
      return _ret;
    }
 
    /**
     * f0 -> <INTEGER_LITERAL>
     */
    public String visit(IntegerLiteral n, String argu) {
       String _ret = n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> <IDENTIFIER>
     */
    public String visit(Label n, String argu) {
       String _ret = n.f0.accept(this, argu);
       return _ret;
    }
 
 }
 