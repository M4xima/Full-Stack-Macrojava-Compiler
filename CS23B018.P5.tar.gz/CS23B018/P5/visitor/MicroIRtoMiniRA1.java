package visitor;
import java.util.*;
import java.util.stream.Collectors;
import syntaxtree.*;

public class MicroIRtoMiniRA1 implements GJVisitor<String, String> {
    //
    // Auto class visitors--probably don't need to be overridden.
    //
    public Map<String, Map<Integer, live>> liveMap = new HashMap<>();
    Map<String, Map<String, Integer>> LabMap = new HashMap<>();
    Set<String> globalUseSet = new HashSet<>();
    int curLine = 1;
    String curProc = null;
    Map<Integer, live> curLiveMap(){
      return liveMap.get(curProc);
    }

    //for linearscan algo
    Map<String, Set<String>> allTemps = new HashMap<>();
    public Map<String, Set<String>> spilledTemps = new HashMap<>();
    public Map<String, Map<String, interval>> tempLines = new HashMap<>();
    public MicroIRtoMiniRA1(Map<String, Map<String, Integer>> LabMap1){
      this.LabMap = LabMap1;
    }

    void liveness(){
      boolean changed = true;
      while(changed){
         changed = false;
         for(String proc: liveMap.keySet()){
            Map<Integer, live> lineMap = liveMap.get(proc);
            for(int line: lineMap.keySet()){
               live l = lineMap.get(line);
               Set<String> oldIn = new HashSet<>(l.in);
               Set<String> oldOut = new HashSet<>(l.out);
               // out[n] = U in[s] for all s in next[n]
               l.out.clear();
               for(int succ: l.next){
                  live ls = lineMap.get(succ);
                  l.out.addAll(ls.in);
               }
               // in[n] = use[n] U (out[n] - def[n])
               l.in.clear();
               l.in.addAll(l.use);
               Set<String> outMinusDef = new HashSet<>(l.out);
               if(l.def != null) outMinusDef.remove(l.def);
               l.in.addAll(outMinusDef);
               if(!l.in.equals(oldIn) || !l.out.equals(oldOut)){
                  changed = true;
               }
            }
         }
      }
     }
     void findIntervals(){
      //collect all temps
      for (Map.Entry<String, Map<Integer, live>> procEntry : liveMap.entrySet()) {
         String proc = procEntry.getKey();
         Map<Integer, live> lines = procEntry.getValue();
         for (Map.Entry<Integer, live> lineEntry : lines.entrySet()) {
            int line = lineEntry.getKey();
            live l = lineEntry.getValue();
            if(l.def != null)allTemps.get(proc).add(l.def);
            allTemps.get(proc).addAll(l.use);
         }
         for(String temp: allTemps.get(proc)){
            tempLines.get(proc).put(temp, new interval(1000000, -1));
         }
      }
      //for finding startpoints
      for (Map.Entry<String, Map<Integer, live>> procEntry : liveMap.entrySet()) {
         String proc = procEntry.getKey();
         Map<Integer, live> lines = procEntry.getValue();
         for (Map.Entry<Integer, live> lineEntry : lines.entrySet()) {
            int line = lineEntry.getKey();
            live l = lineEntry.getValue();
            for(String ins: l.in){
               if(tempLines.get(proc).get(ins).start > line){
                  tempLines.get(proc).get(ins).start = line;
               }
            }
            if(l.def != null){
               if(tempLines.get(proc).get(l.def).start > line){
                  tempLines.get(proc).get(l.def).start = line;
               }
            }
            for(String uses: l.use){
               if(tempLines.get(proc).get(uses).start > line){
                  tempLines.get(proc).get(uses).start = line;
               }
            }
         }   
      }
      //for finding endpoints
      for (Map.Entry<String, Map<Integer, live>> procEntry : liveMap.entrySet()) {
         String proc = procEntry.getKey();
         Map<Integer, live> lines = procEntry.getValue();
         for (Map.Entry<Integer, live> lineEntry : lines.entrySet()) {
            int line = lineEntry.getKey();
            live l = lineEntry.getValue();
            for(String outs: l.out){
               if(tempLines.get(proc).get(outs).end < line){
                  tempLines.get(proc).get(outs).end = line;
               }
            }
            if(l.def != null){
               if(tempLines.get(proc).get(l.def).end < line){
                  tempLines.get(proc).get(l.def).end = line;
               }
            }
            for(String uses: l.use){
               if(tempLines.get(proc).get(uses).end < line){
                  tempLines.get(proc).get(uses).end = line;
               }
            }
         }   
      }   
    }
      void LinearScanRegisterAllocation(){
         int R = 18;
         for (Map.Entry<String, Map<String, interval>> procEntry : tempLines.entrySet()) {
            String proc = procEntry.getKey();
            Map<String, interval> lines = procEntry.getValue();
            Set<Integer> registers = new HashSet<>();
            for (int i = 0; i < R; i++)registers.add(i);
            List<interval> active = new ArrayList<>();
            //sort in incresing order of start time
            Map<String, interval> sortedintervals = lines.entrySet().stream()
                   .sorted(Comparator.comparing(entry -> entry.getValue().start))
                   .collect(Collectors.toMap(
                           Map.Entry::getKey,
                           Map.Entry::getValue,
                           (oldValue, newValue) -> oldValue,
                           LinkedHashMap::new
                   ));
            for(Map.Entry<String, interval> tempEntry : sortedintervals.entrySet()){
               String temp = tempEntry.getKey();
               interval cuInterval = tempEntry.getValue();
               //expire old intervals
               ExpireOldIntervals(cuInterval, active, registers);
               if(registers.isEmpty()){
                  //spill
                  spilledTemps.get(proc).add(temp);
               }else{
                  //assign register
                  int reg = registers.iterator().next();
                  registers.remove(reg);
                  cuInterval.color = reg;
                  active.add(cuInterval);
               }
            }
         }   
      }
      void ExpireOldIntervals(interval cuInterval, List<interval> active, Set<Integer> registers){
         //sort in incresing order of end time
         // System.out.println("1");
         // printActive(active);
         active.sort(Comparator.comparingInt(i -> i.end));
         // System.out.println("2");
         // printActive(active);
         Iterator<interval> iter = active.iterator();
         while(iter.hasNext()){
            interval actInterval = iter.next();
            if(actInterval.end >= cuInterval.start)break;
            registers.add(actInterval.color);
            iter.remove();
         }
      }
    public String visit(NodeList n, String argu) {
       String _ret=null;
       int _count=0;
       for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
          e.nextElement().accept(this,argu);
          _count++;
       }
       return _ret;
    }
 
    public String visit(NodeListOptional n, String argu) {
       if ( n.present() ) {
          String _ret=null;
          int _count=0;
          for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
             e.nextElement().accept(this,argu);
             _count++;
          }
          return _ret;
       }
       else
          return null;
    }
 
    public String visit(NodeOptional n, String argu) {
       if ( n.present() )
          return n.node.accept(this,argu);
       else
          return null;
    }
 
    public String visit(NodeSequence n, String argu) {
       String _ret=null;
       int _count=0;
       for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
          e.nextElement().accept(this,argu);
          _count++;
       }
       return _ret;
    }
 
    public String visit(NodeToken n, String argu) { return n.tokenImage; }
 
    //
    // User-generated visitor methods below
    //
 
    /**
     * f0 -> "MAIN"
     * f1 -> StmtList()
     * f2 -> "END"
     * f3 -> ( Procedure() )*
     * f4 -> <EOF>
     */
    public String visit(Goal n, String argu) {
       String _ret=null;
       curProc = "MAIN";
       liveMap.put(curProc, new HashMap<>());
       allTemps.put(curProc, new HashSet<>());
       spilledTemps.put(curProc, new HashSet<>());
       tempLines.put(curProc, new HashMap<>());
       n.f0.accept(this, argu);
       n.f1.accept(this, argu);
       curLiveMap().put(curLine, new live(null, new HashSet<>(), new HashSet<>()));
       n.f2.accept(this, argu);
       n.f3.accept(this, argu);
       liveness();
      //  debug(); 
       findIntervals();
       LinearScanRegisterAllocation();
      //  debugLinearScan();
       n.f4.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> ( ( Label() )? Stmt() )*
     */
    public String visit(StmtList n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> Label()
     * f1 -> "["
     * f2 -> IntegerLiteral()
     * f3 -> "]"
     * f4 -> StmtExp()
     */
    public String visit(Procedure n, String argu) {
       String _ret=null;
       curProc = n.f0.accept(this, argu);
       liveMap.put(curProc, new HashMap<>());
       allTemps.put(curProc, new HashSet<>());
       spilledTemps.put(curProc, new HashSet<>());
       tempLines.put(curProc, new HashMap<>());
       n.f1.accept(this, argu);
       n.f2.accept(this, argu);
       n.f3.accept(this, argu);
       curLine = 1;
       n.f4.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> NoOpStmt()
     *       | ErrorStmt()
     *       | CJumpStmt()
     *       | JumpStmt()
     *       | HStoreStmt()
     *       | HLoadStmt()
     *       | MoveStmt()
     *       | PrintStmt()
     */
    public String visit(Stmt n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> "NOOP"
     */
    public String visit(NoOpStmt n, String argu) {
       Set<Integer> nextSet = new HashSet<>();
       nextSet.add(curLine + 1);
       curLiveMap().put(curLine, new live(null, new HashSet<>(), nextSet));
       curLine++;
       return null;
    }
 
    /**
     * f0 -> "ERROR"
     */
    public String visit(ErrorStmt n, String argu) {
      Set<Integer> nextSet = new HashSet<>();
      nextSet.add(curLine + 1);
      curLiveMap().put(curLine, new live(null, new HashSet<>(), nextSet));
      curLine++;
      return null;
    }
 
    /**
     * f0 -> "CJUMP"
     * f1 -> Temp()
     * f2 -> Label()
     */
    public String visit(CJumpStmt n, String argu) {
       Set<Integer> nextSet = new HashSet<>();
       Set<String> useSet = new HashSet<>();
       nextSet.add(LabMap.get(curProc).get(n.f2.accept(this, argu)));
       nextSet.add(curLine + 1);
       useSet.add(n.f1.accept(this, argu));
       curLiveMap().put(curLine, new live(null, useSet, nextSet));
       curLine++;
       return null;
       
    }
 
    /**
     * f0 -> "JUMP"
     * f1 -> Label()
     */
    public String visit(JumpStmt n, String argu) {
       Set<Integer> nextSet = new HashSet<>();
       nextSet.add(LabMap.get(curProc).get(n.f1.accept(this, argu)));
       curLiveMap().put(curLine, new live(null, new HashSet<>(), nextSet));
       curLine++;
       return null;
    }
 
    /**
     * f0 -> "HSTORE"
     * f1 -> Temp()
     * f2 -> IntegerLiteral()
     * f3 -> Temp()
     */
    public String visit(HStoreStmt n, String argu) {
       Set<Integer> nextSet = new HashSet<>();
       Set<String> useSet = new HashSet<>();
       nextSet.add(curLine + 1);
       useSet.add(n.f1.accept(this, argu));
       useSet.add(n.f3.accept(this, argu));
       curLiveMap().put(curLine, new live(null, useSet, nextSet));
       curLine++;
       return null;
    }
 
    /**
     * f0 -> "HLOAD"
     * f1 -> Temp()
     * f2 -> Temp()
     * f3 -> IntegerLiteral()
     */
    public String visit(HLoadStmt n, String argu) {
      Set<Integer> nextSet = new HashSet<>();
      Set<String> useSet = new HashSet<>();
      nextSet.add(curLine + 1);
      useSet.add(n.f2.accept(this, argu));
      curLiveMap().put(curLine, new live(n.f1.accept(this, argu), useSet, nextSet));
      curLine++;
      return null;
    }
 
    /**
     * f0 -> "MOVE"
     * f1 -> Temp()
     * f2 -> Exp()
     */
    public String visit(MoveStmt n, String argu) {
      Set<Integer> nextSet = new HashSet<>();
      nextSet.add(curLine + 1);
      globalUseSet = new HashSet<>();
      n.f2.accept(this, argu);
      curLiveMap().put(curLine, new live(n.f1.accept(this, argu), globalUseSet, nextSet));
      curLine++;
      return null;
    }
 
    /**
     * f0 -> "PRINT"
     * f1 -> SimpleExp()
     */
    public String visit(PrintStmt n, String argu) {
       Set<Integer> nextSet = new HashSet<>();
       Set<String> useSet = new HashSet<>();
       nextSet.add(curLine + 1);
       if(n.f1.accept(this, argu).startsWith("TEMP"))useSet.add(n.f1.accept(this, argu));
       curLiveMap().put(curLine, new live(null, useSet, nextSet));
       curLine++;
       return null;
    }
 
    /**
     * f0 -> Call()
     *       | HAllocate()
     *       | BinOp()
     *       | SimpleExp()
     */
    public String visit(Exp n, String argu) {
       String _ret=null;
       if(n.f0.which == 3){
         if(n.f0.accept(this, argu).startsWith("TEMP"))globalUseSet.add(n.f0.accept(this, argu));
         return null;
       }
       return n.f0.accept(this, argu);
    }
 
    /**
     * f0 -> "BEGIN"
     * f1 -> StmtList()
     * f2 -> "RETURN"
     * f3 -> SimpleExp()
     * f4 -> "END"
     */
    public String visit(StmtExp n, String argu) {
         String _ret=null;
         n.f0.accept(this, argu);
         n.f1.accept(this, argu);
         n.f2.accept(this, argu);
         n.f3.accept(this, argu);
         Set<Integer> nextSet = new HashSet<>();
         Set<String> useSet = new HashSet<>();
         if(n.f3.accept(this, argu).startsWith("TEMP"))useSet.add(n.f3.accept(this, argu));
         curLiveMap().put(curLine, new live(null, useSet, nextSet));
         curLine++;
         return _ret;
    }
 
    /**
     * f0 -> "CALL"
     * f1 -> SimpleExp()
     * f2 -> "("
     * f3 -> ( Temp() )*
     * f4 -> ")"
     */
    public String visit(Call n, String argu) {
       globalUseSet.add(n.f1.accept(this, argu));
         for ( Enumeration<Node> e = n.f3.elements(); e.hasMoreElements(); ) {
            String temp = e.nextElement().accept(this, argu);
            globalUseSet.add(temp);
         }
       return null;
    }
 
    /**
     * f0 -> "HALLOCATE"
     * f1 -> SimpleExp()
     */
    public String visit(HAllocate n, String argu) {
       if(n.f1.accept(this, argu).startsWith("TEMP"))globalUseSet.add(n.f1.accept(this, argu));
       return null;
    }
 
    /**
     * f0 -> Operator()
     * f1 -> Temp()
     * f2 -> SimpleExp()
     */
    public String visit(BinOp n, String argu) {
      globalUseSet.add(n.f1.accept(this, argu));
      if(n.f2.accept(this, argu).startsWith("TEMP"))globalUseSet.add(n.f2.accept(this, argu));
       return null;
    }
 
    /**
     * f0 -> "LE"
     *       | "NE"
     *       | "PLUS"
     *       | "MINUS"
     *       | "TIMES"
     *       | "DIV"
     */
    public String visit(Operator n, String argu) {
       String _ret=null;
       n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> Temp()
     *       | IntegerLiteral()
     *       | Label()
     */
    public String visit(SimpleExp n, String argu) {
       String _ret = n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> "TEMP"
     * f1 -> IntegerLiteral()
     */
    public String visit(Temp n, String argu) {
       String _ret = "TEMP " + n.f1.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> <INTEGER_LITERAL>
     */
    public String visit(IntegerLiteral n, String argu) {
       String _ret = n.f0.accept(this, argu);
       return _ret;
    }
 
    /**
     * f0 -> <IDENTIFIER>
     */
    public String visit(Label n, String argu) {
       String _ret = n.f0.accept(this, argu);
       return _ret;
    }
  
   public void debug() {
      System.out.println("======= DEBUG INFO =======");
      System.out.println("Current Procedure: " + curProc);
      System.out.println("Current Line: " + curLine);

      System.out.println("\n-- Global Use Set --");
      for (String var : globalUseSet) {
         System.out.println("  " + var);
      }

      System.out.println("\n-- Label Map (LabMap) --");
      for (Map.Entry<String, Map<String, Integer>> procEntry : LabMap.entrySet()) {
         String proc = procEntry.getKey();
         System.out.println("Procedure: " + proc);
         for (Map.Entry<String, Integer> labelEntry : procEntry.getValue().entrySet()) {
            System.out.println("   Label: " + labelEntry.getKey() + " → Line: " + labelEntry.getValue());
         }
      }

      System.out.println("\n-- Live Map (liveMap) --");
      for (Map.Entry<String, Map<Integer, live>> procEntry : liveMap.entrySet()) {
         String proc = procEntry.getKey();
         System.out.println("Procedure: " + proc);
         Map<Integer, live> lines = procEntry.getValue();
         for (Map.Entry<Integer, live> lineEntry : lines.entrySet()) {
            int line = lineEntry.getKey();
            live l = lineEntry.getValue();
            System.out.println("  Line " + line + ":");
            System.out.println("     def  = " + l.def);
            System.out.println("     use  = " + l.use);
            System.out.println("     in   = " + l.in);
            System.out.println("     out  = " + l.out);
            System.out.println("     next = " + l.next);
         }
      }

      System.out.println("==========================\n");
   }
  public void debugLinearScan() {
      System.out.println("========== LINEAR SCAN DEBUG ==========");
      
      // ---- allTemps ----
      System.out.println("\n-- All Temps --");
      for (Map.Entry<String, Set<String>> procEntry : allTemps.entrySet()) {
         String proc = procEntry.getKey();
         System.out.println("Procedure: " + proc);
         System.out.println("   Temps: " + procEntry.getValue());
      }

      // ---- spilledTemps ----
      System.out.println("\n-- Spilled Temps --");
      for (Map.Entry<String, Set<String>> procEntry : spilledTemps.entrySet()) {
         String proc = procEntry.getKey();
         System.out.println("Procedure: " + proc);
         System.out.println("   Spilled: " + procEntry.getValue());
      }

      // ---- tempLines ----
      System.out.println("\n-- Temp Intervals (tempLines) --");
      for (Map.Entry<String, Map<String, interval>> procEntry : tempLines.entrySet()) {
         String proc = procEntry.getKey();
         System.out.println("Procedure: " + proc);
         Map<String, interval> temps = procEntry.getValue();
         Map<String, interval> sortedTemps = temps.entrySet().stream()
               .sorted(Comparator.comparing(entry -> entry.getValue().color))
               .collect(Collectors.toMap(
                       Map.Entry::getKey,
                       Map.Entry::getValue,
                       (oldValue, newValue) -> oldValue,
                       LinkedHashMap::new
               ));
         for (Map.Entry<String, interval> tempEntry : sortedTemps.entrySet()) {
            String temp = tempEntry.getKey();
            interval inter = tempEntry.getValue();
            System.out.printf("   Temp: %-8s  Start: %-3d  End: %-3d  Color: %-2d%n",
                              temp, inter.start, inter.end, inter.color);
         }
      }

      System.out.println("=======================================");
   }
   public void printLines(Map<String, interval> lines) {
      System.out.println("===== INTERVAL MAP =====");
  
      if (lines == null || lines.isEmpty()) {
          System.out.println("Map is empty.");
          return;
      }
  
      // Optional: sort by start (ascending)
      List<Map.Entry<String, interval>> sortedList = new ArrayList<>(lines.entrySet());
      sortedList.sort(Comparator.comparingInt(e -> e.getValue().start));
  
      for (Map.Entry<String, interval> entry : sortedList) {
          String temp = entry.getKey();
          interval i = entry.getValue();
          System.out.printf("Temp: %-8s | Start: %-3d | End: %-3d | Color: %-2d%n",
                            temp, i.start, i.end, i.color);
      }
  
      System.out.println("========================");
  }
  public void printActive(List<interval> active) {
    System.out.println("===== ACTIVE INTERVALS =====");

    if (active == null || active.isEmpty()) {
        System.out.println("No active intervals.");
        return;
    }

    // Sort by start time for readability (optional)
    List<interval> sorted = new ArrayList<>(active);

    int idx = 0;
    for (interval i : sorted) {
        System.out.printf("[%02d] Start: %-3d | End: %-3d | Color: %-2d%n",
                          idx++, i.start, i.end, i.color);
    }

    System.out.println("============================");
}


  
 }
 