package visitor;

import java.util.HashSet;
import java.util.Set;

public class interval{
    public int start;
    public int end;
    public int color; // assigned register
    public interval(int s, int e){
        start = s;
        end = e;
        color = -1; // not assigned
    }
}