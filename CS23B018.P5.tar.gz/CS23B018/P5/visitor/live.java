package visitor;

import java.util.HashSet;
import java.util.Set;

public class live {
    public Set<String> in;
    public Set<String> out;
    public String def;
    public Set<String> use;
    public Set<Integer> next;
    public live(){
        in = new HashSet<>();
        out = new HashSet<>();
        def = null;
        use = new HashSet<>();
        next = new HashSet<>();
    }
    public live(String def1, 
            Set<String> use1, 
            Set<Integer> next1){
        in = new HashSet<>();
        out = new HashSet<>();
        def = def1;
        use = new HashSet<>(use1);
        next = new HashSet<>(next1);
    }
}
