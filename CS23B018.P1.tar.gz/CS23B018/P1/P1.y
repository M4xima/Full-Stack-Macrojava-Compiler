/* %debug */
%{
    #include <iostream>
    #include <cstdio>
    #include <cstdlib>
    #include <cstring>
    #include <string>
    #include <vector>
    #include <map>
    #include <set>
    #include <cassert>
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <sstream>
    using namespace std;
    void yyerror(char *);
    int yylex(void);

    int line_counter = 1;
    char* output;
    int parno = 1;
    string curClass;
    map < string , map < string, string > > mp;
    map < string , string > expand;
    set < string > expre, stat;
    string miniJava;
    bool inDef = false;
    bool inLambda = false;
    int tabs = 0;
    char *concat(const char *a, const char *b) {
        if (!a) a = "";
        if (!b) b = "";
        size_t la = strlen(a);
        size_t lb = strlen(b);
        char *out = (char *)malloc(la + lb + 1);   // +1 for NUL
        if (!out) return NULL;
        memcpy(out, a, la);
        memcpy(out + la, b, lb);
        out[la + lb] = '\0';
        return out; // caller must free()
    }
    bool digit(char c){
        if(c >= '0' and c <= '9')return true;
        return false;
    }
    string expandMacroStat(string class1, string arguments){
        // cout << class1 << " " << arguments << "\n";
        stringstream ss(arguments);
        string token;
        vector < string > result(1, "");
        while (getline(ss, token, ',')) {
            result.push_back(token); 
            // cout << result[result.size() - 1];
        }
        cout << "\n";
        string s = expand[class1];
        string ans;
        for(int i = 0;i < s.size();i ++){
            if(s[i] == '$'){
                string temp = "";
                int j = i + 1;
                for(;j < s.size() and digit(s[j]);j ++){
                    temp += s[j];
                }
                i = j - 1;
                ans += " " + result[stoi(temp)] + " ";
            }
            else ans += s[i];
        }
        return ans;
    }
    string expandMacroExpre(string class1, string arguments){
        // cout << class1 << " " << arguments << "\n";
        stringstream ss(arguments);
        string token;
        vector < string > result(1, "");
        while (getline(ss, token, ',')) {
            result.push_back(token); 
            // cout << result[result.size() - 1];
        }
        cout << "\n";
        string s = expand[class1];
        string ans;
        for(int i = 0;i < s.size();i ++){
            if(s[i] == '$'){
                string temp = "";
                int j = i + 1;
                for(;j < s.size() and digit(s[j]);j ++){
                    temp += s[j];
                }
                i = j - 1;
                ans += "(" + result[stoi(temp)] + ")";
            }
            else ans += s[i];
        }
        return ans;
    }
    string expandMacro1(string class1, string arguments){
        stringstream ss(arguments);
        string token;
        vector < string > result(1, "");
        while (getline(ss, token, ',')) {
            result.push_back(token); 
        }
        string s = expand[class1];
        string ans;
        for(int i = 0;i < s.size();i ++){
            if(s[i] == '$'){
                string temp = "";
                int j = i + 1;
                for(;j < s.size() and digit(s[j]);j ++){
                    temp += s[j];
                }
                i = j - 1;
                ans += "(" + mp[curClass][temp] + ")";
            }
            else ans += s[i];
        }
        return ans;
    }
    string random(string s){

    }
    void printMiniJavaCode(){
        cout << miniJava << "\n";
    }

%}

%union {
    char* val;
}

%token <val> IMFN DEFINE IDENTIFIER CLASS PUBLIC STATIC MAIN FUNCTION
%token <val> VOID INT STRING BOOLEAN INTEGER
%token <val> OPAREN CPAREN OBRACE CBRACE OBRACK CBRACK OANGLE CANGLE
%token <val> SC COMMA DOT LENGTH ARROW THIS NOT NEW
%token <val> IF ELSE WHILE RETURN EQ NEQ SYSTEMOUT
%token <val> PLUS MINUS TIMES DIV LEQ OR AND TRUE FALSE EXTENDS
%type <val> Goal Prog Macro StatementList MacroDefExpression MacroDefStatement
%type <val> IdentifierList IdentifierRightList ExpressionList ExpressionRightList
FormalParameterList FormalParameter FormalParameterRest VarDeclarationList VarDeclaration
MethodDeclarationList MethodDeclaration Code NoMainCode MainClass TypeDecl Type Printstmt
Expression PrimaryExpression Statement Macro1 BlockBody

%nonassoc OTHER_THAN_ELSE
%nonassoc ELSE

%left OR 
%left AND
%nonassoc EQ NEQ LEQ
%left PLUS MINUS
%left TIMES DIV
%right NOT

%start Goal

%%
Goal : IMFN Prog {cout << "import java.util.function.Function;\n" << miniJava << "\n";}
    | Prog {cout << miniJava << "\n";}
Prog : Macro Prog
    | Code

//Macros
Macro : DEFINE IDENTIFIER {curClass = $2; parno = 1; inDef = true;} OPAREN IdentifierList CPAREN Macro1
Macro1 : MacroDefExpression {$$ = $1;}| MacroDefStatement {$$ = $1;}
MacroDefStatement : OBRACE StatementList CBRACE {inDef = false; stat.insert(curClass); expand[curClass] = concat(concat("{", $2), "}");}
MacroDefExpression : OPAREN Expression CPAREN {inDef = false; expre.insert(curClass); expand[curClass] = concat(concat("(", $2), ")");}

//Lists
IdentifierList : IDENTIFIER {mp[curClass][$1] = "$" + to_string(parno); parno ++;} IdentifierRightList | ;
IdentifierRightList : COMMA IDENTIFIER {mp[curClass][$2] = "$" + to_string(parno); parno ++;} IdentifierRightList | ;

ExpressionList : ExpressionRightList Expression{$$ = concat($1,$2);}| {$$ = "";};
ExpressionRightList : ExpressionRightList Expression COMMA {$$ = concat(concat($1, $2), ", ");}| {$$ = "";};

StatementList : Statement StatementList{$$ = concat($1,$2);}| {$$ = "";};

FormalParameterList : FormalParameterRest FormalParameter{$$ = concat($1,$2);}| {$$ = "";};
FormalParameter	: Type IDENTIFIER {$$ = concat($1,$2);}
FormalParameterRest	: FormalParameterRest FormalParameter COMMA {$$ = concat(concat($1,$2), ", ");}| {$$ = "";};

VarDeclarationList :  VarDeclarationList VarDeclaration{$$ = concat($1, $2);}| {$$ = "";};
VarDeclaration : Type IDENTIFIER SC {$$ = concat(concat($1, $2), ";\n");}

MethodDeclarationList : MethodDeclarationList MethodDeclaration{$$ = concat($1, $2);}| {$$ = "";};
MethodDeclaration : PUBLIC Type IDENTIFIER OPAREN FormalParameterList CPAREN OBRACE BlockBody RETURN Expression SC CBRACE 
                    {$$ = concat(concat(concat(concat(concat(concat("public ", $2), $3), $4), $5), " ) { "),concat(concat(concat($8, "return "), $10), "; \n}\n"));}
BlockBody : VarDeclarationList StatementList {$$ = concat($1, $2);}
Code : MainClass NoMainCode {$$ = concat($1, $2); miniJava = string($$);}
NoMainCode : NoMainCode TypeDecl{$$ = concat($1, $2);}| {$$ = "";};
MainClass : CLASS IDENTIFIER OBRACE PUBLIC STATIC VOID MAIN OPAREN STRING OBRACK CBRACK IDENTIFIER CPAREN OBRACE
            Printstmt CBRACE CBRACE {$$ = concat(concat(concat(concat(concat(concat("class ", $2), "{ \npublic static void main ( String [] "), $12), " ) \n{\n"), $15), "}\n }\n");}
TypeDecl : CLASS IDENTIFIER OBRACE VarDeclarationList MethodDeclarationList CBRACE {$$ = concat(concat(concat(concat(concat("class ", $2), "{\n"), $4), $5), "\n}\n");}
    | CLASS IDENTIFIER EXTENDS IDENTIFIER OBRACE VarDeclarationList MethodDeclarationList CBRACE {$$ = concat(concat(concat(concat(concat(concat("class ", $2), concat(" extends ", $4)), "{\n"), $6), $7), "\n}\n");}

Type :	INT OBRACK CBRACK {$$ = "int[] ";}
    | BOOLEAN {$$ = "boolean ";}
    | INT {$$ = "int ";}
    | IDENTIFIER {$$ = concat($1, " ");}
    | FUNCTION OANGLE IDENTIFIER COMMA IDENTIFIER CANGLE {$$ = concat(concat(concat(concat(" Function < ", $3), ","), $5), " > ");}

Printstmt : SYSTEMOUT OPAREN Expression CPAREN SC {$$ = concat(concat("System.out.println( ", $3), " );\n");}
Expression : PrimaryExpression AND PrimaryExpression {$$ = concat(concat($1, " && "), $3);}
    | PrimaryExpression OR PrimaryExpression {$$ = concat(concat($1, " || "), $3);}
    | PrimaryExpression NEQ PrimaryExpression {$$ = concat(concat($1, " != "), $3);}
    | PrimaryExpression LEQ PrimaryExpression {$$ = concat(concat($1, " <= "), $3);}
    | PrimaryExpression PLUS PrimaryExpression {$$ = concat(concat($1, " + "), $3);}
    | PrimaryExpression MINUS PrimaryExpression {$$ = concat(concat($1, " - "), $3);}
    | PrimaryExpression TIMES PrimaryExpression {$$ = concat(concat($1, " * "), $3);}
    | PrimaryExpression DIV PrimaryExpression {$$ = concat(concat($1, " / "), $3);}
    | PrimaryExpression OBRACK PrimaryExpression CBRACK {$$ = concat(concat(concat($1, $2), $3), $4);}
    | PrimaryExpression DOT LENGTH {$$ = concat(concat($1, $2), $3);}
    | PrimaryExpression {$$ = $1;}
    | PrimaryExpression DOT IDENTIFIER OPAREN ExpressionList CPAREN {$$ = concat(concat(concat(concat(concat($1, $2), $3), $4), $5), $6);}
    | IDENTIFIER OPAREN ExpressionList CPAREN /* Macro expr call */ { if(stat.count($1)){yyerror((char*)"");} $$ = strdup(expandMacroExpre($1, $3).c_str());}
    | OPAREN IDENTIFIER CPAREN ARROW {inLambda = true;}Expression {
        inLambda = false;
        if(inDef and mp[curClass].count($2)){
            $$ = concat(concat(concat(" ( ", strdup((mp[curClass][$2]).c_str())), " ) -> "), $6);
        }
        else{
            $$ = concat(concat(concat($1, $2), " ) -> "), $6
            );
        }
    }
PrimaryExpression : INTEGER {$$ = $1;}
    | TRUE {$$ = $1;}
    | FALSE {$$ = $1;}
    | IDENTIFIER {
        if(inDef and mp[curClass].count($1)){
            $$ = strdup((mp[curClass][$1]).c_str());
        }
        else{
            $$ = $1;
        } 
    } 
    | THIS {$$ = $1;}
    | NEW INT OBRACK Expression CBRACK {$$ = concat(concat(" new int [ ", $4), " ] ");}
    | NEW IDENTIFIER OPAREN CPAREN {
        if(inDef and mp[curClass].count($2)){
            $$ = concat(concat("new ", strdup((mp[curClass][$2]).c_str())), "()");
        }
        else{
            $$ = concat(concat("new ", $2), "()");
        }
    }
    | NOT Expression {$$ = concat(" ! ",$2);}
    | OPAREN Expression CPAREN {$$ = concat(concat(" ( ", $2), " ) ");}
    /* |Expression {$$ = $1;} */
Statement : OBRACE StatementList CBRACE {$$ = concat(concat("{\n", $2), "\n}\n");}
    | Printstmt {$$ = $1;}
    | IDENTIFIER EQ Expression SC {
        if(inDef and mp[curClass].count($1)){
            $$ = concat(concat(concat(strdup(mp[curClass][$1].c_str()), " = "), $3), " ;\n");
        }else{
            $$ = concat(concat(concat($1, " = "), $3), " ;\n");
        }
    } 
    | IDENTIFIER OBRACK Expression CBRACK EQ Expression SC {
        if(inDef and mp[curClass].count($1)){
            $$ = concat(concat(concat(concat(concat(strdup(mp[curClass][$1].c_str()), " ["), $3), concat("]", $5)), $6), ";\n");
        }else{
            $$ = concat(concat(concat(concat(concat($1, "["), $3), concat("]", $5)), $6), ";\n");
        }
    }
    | IF OPAREN Expression CPAREN Statement {$$ = concat(concat(concat(concat("if ( ", $3), " ) "), $5), "\n");} %prec OTHER_THAN_ELSE
    | IF OPAREN Expression CPAREN Statement ELSE Statement {$$ = concat(concat(concat(concat(concat(concat("if ( " , $3), " ) "), $5), "else "), $7), "\n");}
    | WHILE OPAREN Expression CPAREN Statement {$$ = concat(concat(concat(concat(concat("while", " ( "), $3), " ) \n"), $5), "\n");}
    | IDENTIFIER OPAREN ExpressionList CPAREN SC /* Macro stmt call */ { $$ = strdup(expandMacroStat($1, $3).c_str());}

%%


/* extern int yydebug; */

void yyerror(char *s) {
    /* fprintf(stderr,"%d\n", line_counter); */
    fprintf(stdout,"// Failed to parse macrojava code.");
    exit(1);
}

int main(void) {
    /* yydebug = 1; */
    /* if (yyparse() == 0) printMiniJavaCode(); 
    else fprintf(stdout,"// Failed to parse macrojava code."); */
    yyparse();
    return 0;
}
 