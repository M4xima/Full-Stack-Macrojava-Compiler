package visitor;
import java.util.*;
import syntaxtree.*;

public class MiniToMicro implements GJVisitor<String, String> {
   //
   // Auto class visitors--probably don't need to be overridden.
   //
   int tempCount = 100;
   String newTemp (){
      return "TEMP " + (tempCount++);
   }
   public String visit(NodeList n, String argu) {
      String _ret=null;
      int _count=0;
      for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
         e.nextElement().accept(this,argu);
         _count++;
      }
      return _ret;
   }

   public String visit(NodeListOptional n, String argu) {
      if ( n.present() ) {
         String _ret = "";
         int _count=0;
         for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
            _ret += e.nextElement().accept(this,argu) + " ";
            _count++;
         }
         return _ret;
      }
      else
         return null;
   }

   public String visit(NodeOptional n, String argu) {
      if ( n.present() )
         return n.node.accept(this,argu);
      else
         return null;
   }

   public String visit(NodeSequence n, String argu) {
      String _ret=null;
      int _count=0;
      for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
         e.nextElement().accept(this,argu);
         _count++;
      }
      return _ret;
   }

   public String visit(NodeToken n, String argu) { return n.tokenImage; }

   //
   // User-generated visitor methods below
   //

   /**
    * f0 -> "MAIN"
    * f1 -> StmtList()
    * f2 -> "END"
    * f3 -> ( Procedure() )*
    * f4 -> <EOF>
    */
   public String visit(Goal n, String argu) {
      System.out.println("MAIN");
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      System.out.println("END");
      n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      n.f4.accept(this, argu);
      return null;
   }

   /**
    * f0 -> ( ( Label() )? Stmt() )*
    */
   public String visit(StmtList n, String argu) {
      n.f0.accept(this, argu);
      return null;
   }

   /**
    * f0 -> Label()
    * f1 -> "["
    * f2 -> IntegerLiteral()
    * f3 -> "]"
    * f4 -> StmtExp()
    */
   public String visit(Procedure n, String argu) {
      n.f0.accept(this, argu);
      System.out.print(" [");
      n.f2.accept(this, argu);
      System.out.println("]");
      System.out.println("BEGIN");
      String _ret = n.f4.accept(this, argu);
      System.out.println("RETURN " + _ret);
      System.out.println("END");
      return null;
   }

   /**
    * f0 -> NoOpStmt()
    *       | ErrorStmt()
    *       | CJumpStmt()
    *       | JumpStmt()
    *       | HStoreStmt()
    *       | HLoadStmt()
    *       | MoveStmt()
    *       | PrintStmt()
    */
   public String visit(Stmt n, String argu) {
      n.f0.accept(this, argu);
      return null;
   }

   /**
    * f0 -> "NOOP"
    */
   public String visit(NoOpStmt n, String argu) {
      System.out.println("NOOP");
      return null;
   }

   /**
    * f0 -> "ERROR"
    */
   public String visit(ErrorStmt n, String argu) {
      System.out.println("ERROR");
      return null;
   }

   /**
    * f0 -> "CJUMP"
    * f1 -> Exp()
    * f2 -> Label()
    */
   public String visit(CJumpStmt n, String argu) {
      String expr = n.f1.accept(this, argu);
      System.out.print("CJUMP " + expr + " ");
      n.f2.accept(this, argu);
      return null;
   }

   /**
    * f0 -> "JUMP"
    * f1 -> Label()
    */
   public String visit(JumpStmt n, String argu) {
      String _ret=null;
      System.out.print("JUMP ");
      n.f1.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "HSTORE"
    * f1 -> Exp()
    * f2 -> IntegerLiteral()
    * f3 -> Exp()
    */
   public String visit(HStoreStmt n, String argu) {
      String _ret=null;
      String expr1 = n.f1.accept(this, argu);
      String expr2 = n.f3.accept(this, argu);
      System.out.print("HSTORE " + expr1 + " ");
      n.f2.accept(this, argu);
      System.out.print(" " + expr2 + "\n");
      return _ret;
   }

   /**
    * f0 -> "HLOAD"
    * f1 -> Temp()
    * f2 -> Exp()
    * f3 -> IntegerLiteral()
    */
   public String visit(HLoadStmt n, String argu) {
      String _ret=null;
      String expr = n.f2.accept(this, argu);
      System.out.print("HLOAD ");
      n.f1.accept(this, argu);
      System.out.print(" " + expr + " ");
      n.f3.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "MOVE"
    * f1 -> Temp()
    * f2 -> Exp()
    */
   public String visit(MoveStmt n, String argu) {
      String _ret=null;
      String expr = n.f2.accept(this, argu);
      System.out.print("MOVE ");
      n.f1.accept(this, argu);
      System.out.print(" " + expr + "\n");
      return _ret;
   }

   /**
    * f0 -> "PRINT"
    * f1 -> Exp()
    */
   public String visit(PrintStmt n, String argu) {
      String _ret=null;
      String expr = n.f1.accept(this, argu);
      System.out.print("PRINT " + expr + "\n");
      return _ret;
   }

   /**
    * f0 -> StmtExp()
    *       | Call()
    *       | HAllocate()
    *       | BinOp()
    *       | Temp()
    *       | IntegerLiteral()
    *       | Label()
    */
   public String visit(Exp n, String argu) {
      if(n.f0.which == 4 || n.f0.which == 5 || n.f0.which == 6){
         String temp = newTemp();
         System.out.println("MOVE " + temp);
         n.f0.accept(this, argu);
         return temp;
      }
      return n.f0.accept(this, argu);
   }

   /**
    * f0 -> "BEGIN"
    * f1 -> StmtList()
    * f2 -> "RETURN"
    * f3 -> Exp()
    * f4 -> "END"
    */
   public String visit(StmtExp n, String argu) {
      n.f1.accept(this, argu);
      String expr = n.f3.accept(this, argu);
      String temp = newTemp();
      System.out.println("MOVE " + temp);
      System.out.println(expr);
      return temp;
   }

   /**
    * f0 -> "CALL"
    * f1 -> Exp()
    * f2 -> "("
    * f3 -> ( Exp() )*
    * f4 -> ")"
    */
   public String visit(Call n, String argu) {
      String temp = newTemp();
      String func = n.f1.accept(this, argu);
      String exprList = n.f3.accept(this, argu);
      System.out.println("MOVE " + temp);
      System.out.print("CALL " + func);
      System.out.print(" (");
      if (exprList != null) {
         System.out.print(exprList);
      }
      System.out.println(")");
      return temp;
   }

   /**
    * f0 -> "HALLOCATE"
    * f1 -> Exp()
    */
   public String visit(HAllocate n, String argu) {
      String temp = newTemp();
      String expr = n.f1.accept(this, argu);
      System.out.println("MOVE " + temp);
      System.out.print(" HALLOCATE " + expr + "\n");
      return temp;
   }

   /**
    * f0 -> Operator()
    * f1 -> Exp()
    * f2 -> Exp()
    */
   public String visit(BinOp n, String argu) {
      String expr1 = n.f1.accept(this, argu);
      String expr2 = n.f2.accept(this, argu);
      String temp = newTemp();
      System.out.println("MOVE " + temp);
      n.f0.accept(this, argu);
      System.out.print(" " + expr1 + " " + expr2 + "\n");
      return temp;
   }

   /**
    * f0 -> "LE"
    *       | "NE"
    *       | "PLUS"
    *       | "MINUS"
    *       | "TIMES"
    *       | "DIV"
    */
   public String visit(Operator n, String argu) {
      System.out.print(n.f0.accept(this, argu));
      return null;
   }

   /**
    * f0 -> "TEMP"
    * f1 -> IntegerLiteral()
    */
   public String visit(Temp n, String argu) {
      System.out.print("TEMP ");
      n.f1.accept(this, argu);
      return null;
   }

   /**
    * f0 -> <INTEGER_LITERAL>
    */
   public String visit(IntegerLiteral n, String argu) {
      System.out.print(" " + n.f0.toString() + "\n");
      return null;
   }

   /**
    * f0 -> <IDENTIFIER>
    */
   public String visit(Label n, String argu) {
      System.out.print(" " + n.f0.toString() + "\n");
      return null;
   }

}
