import syntaxtree.*;
import visitor.*;

public class P2 {
   public static void main(String [] args) {
      try {
         Node root = new MiniJavaParser(System.in).Goal();
         // System.out.println("Program parsed successfully");
         GJNoArguDepthFirst<String> parser1 = new GJNoArguDepthFirst<String>();
         root.accept(parser1); // Your assignment part is invoked here.
         GJDepthFirst<String, String> parser2 = new GJDepthFirst<String, String>(parser1.classes);
         root.accept(parser2, "0");
         // GJNoArguDepthFirst1<String> parser3 = new GJNoArguDepthFirst1<String>(parser1.classes);
         // root.accept(parser3);
         System.out.println("Program type checked successfully");
      }
      // catch (ParseException e) {
      //    System.out.println(e.toString());
      // }
      catch (MyException e){
         System.out.println(e.getMessage());
      }
      catch (Exception e){
         System.out.println("Type error");
      }
   }
} 


