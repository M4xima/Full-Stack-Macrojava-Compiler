package visitor;
import java.text.ParseException;
import java.util.*;

import javax.print.PrintException;
import javax.swing.UIManager.LookAndFeelInfo;

import syntaxtree.*;

/**
 * Provides default methods which visit each node in the tree in depth-first
 * order.  Your visitors may extend this class.
 */
public class GJNoArguDepthFirst1<R> implements GJNoArguVisitor<R> {

   String curClass = "NoClassYet";
   String curMethod = "NoMethodYet";
   boolean accessing = false;
   boolean inLamda = false;
   String accessClass = "NoClassYet";
   String accessMethod = "NoMethodYet";
   String LamdaArg = null;
   Map<String, ClassObj> classes;
   Map<String, String> LamdaLocal = new HashMap<>();
   Map<String, String> Wrapper = new HashMap<>();
   public GJNoArguDepthFirst1(Map<String, ClassObj> classes1){
      classes = classes1;
      Wrapper.put("Integer", "int");
      Wrapper.put("Boolean", "boolean");
   }
   public void typeError() throws MyException {
      throw new MyException("Type error");
   }
   public void SymbolNotFound() throws MyException {
      throw new MyException("Symbol not found");
   }
   public String IsLamda(String var, String cur){
      MethodObj methodname = classes.get(cur).methods.get(curMethod);
      if(methodname != null){
         String inmethod = methodname.mAttributes.get(var);
         if(inmethod != null && inmethod.contains("#"))return inmethod;
         for (List<String> argList :methodname.arguments) {
            if(argList.get(0).equals(var) && argList.get(1).contains("#"))return argList.get(1);
         };
      }   
      String inclass = classes.get(cur).cAttributes.get(var);
      if(inclass != null && inclass.contains("#"))return inclass;
      return null;
   }
   public String IsLamdaLoop(String var){
      String cur = curClass;
      String temp = IsLamda(var, cur);
      if(temp != null)return temp;
      cur = classes.get(cur).par;
      while(cur != null){
         String inclass = classes.get(cur).cAttributes.get(var);
         if(inclass != null && inclass.contains("#"))return inclass;
         // System.out.println("Inloop before cur = " + cur);
         cur = classes.get(cur).par;
         // System.out.println("Inloop after cur = " + cur);
      }
      return null;
   }
   public void CheckArgs(String args, String class1, String method1){
      // System.out.println(args);
      if(args == null){
         if(classes.get(class1).methods.get(method1).arguments.size() != 0)typeError();
         return;
      }
      String[] parts = args.split(",");
      List<String> args1 = Arrays.asList(parts);
      List<List<String>> args2 = classes.get(class1).methods.get(method1).arguments;
      // System.out.println(args1);
      // System.out.println(args2 + "\n");
      if(args1.size() != args2.size())typeError();
      for(int i = 0;i < args1.size();i ++){
         String s1 = args1.get(i);
         String s2 = args2.get(i).get(1);
         if(!Path(s1, s2))typeError();
      }
   }
   public String findVar(String var, String cur){
      if(classes.get(var) != null)return var;
      // //debugging start
      // ClassObj c = classes.get(cur);
      // if (c == null) {
      //    throw new MyException("Class " + cur + " not declared");
      // }
      // //debugging end
      if(classes.get(cur).methods.get(var) != null)return var;
      if(Wrapper.get(var) != null)return Wrapper.get(var);
      if(LamdaLocal.get(var) != null)return LamdaLocal.get(var);
      MethodObj methodname = classes.get(cur).methods.get(curMethod);
      if(methodname != null){
         String inmethod = methodname.mAttributes.get(var);
         if(inmethod != null)return inmethod;
         for (List<String> argList :methodname.arguments) {
            if(argList.get(0).equals(var))return argList.get(1);
         };
      }   
      String inclass = classes.get(cur).cAttributes.get(var);
      if(inclass != null)return inclass;
      // System.out.println("Symbol not found -> " + var);
      // SymbolNotFound();
      return null;
   }
   public String findVarLoop(String var){
      // System.out.println(var);
      String cur = curClass;
      String temp = findVar(var, cur);
      if(temp != null)return temp;
      cur = classes.get(cur).par;
      while(cur != null){
         String inclass = classes.get(cur).cAttributes.get(var);
         if(inclass != null)return inclass;
         // System.out.println("Inloop before cur = " + cur);
         cur = classes.get(cur).par;
         // System.out.println("Inloop after cur = " + cur);
      }
      // System.out.println("Symbol not found -> " + var);
      SymbolNotFound();
      return null;
   }
   public void ClassExists(String class1){
      if(classes.get(class1) == null)SymbolNotFound();
   }
   public void PlaceMethodParam(String var){
      classes.get(curClass).methods.get(curMethod).arguments.size();
   }
   public boolean Path(String child,String par){
      String cur = child;
      while(cur != null){
         if(cur.equals(par))return true;
         cur = classes.get(cur).par;
      }
      return false;
   }
   public R visit(NodeList n) {
      R _ret = null;
      int _count=0;
      for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
         e.nextElement().accept(this);
         _count++;
      }
      return _ret;
   }

   public R visit(NodeListOptional n) {
      if ( n.present() ) {
         String ans = "";
         int _count=0;
         for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
            ans += e.nextElement().accept(this);
            _count++;
         }
         return (R)ans;
      }
      else
         return null;
   }

   public R visit(NodeOptional n) {
      if ( n.present() )
         return n.node.accept(this);
      else
         return null;
   }

   public R visit(NodeSequence n) {
      R _ret=null;
      int _count=0;
      for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
         e.nextElement().accept(this);
         _count++;
      }
      return _ret;
   }

   public R visit(NodeToken n) { return (R)n.tokenImage; }

   //
   // User-generated visitor methods below
   //

   /**
    * f0 -> ( ImportFunction() )?
    * f1 -> MainClass()
    * f2 -> ( TypeDeclaration() )*
    * f3 -> <EOF>
    */
   public R visit(Goal n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      n.f2.accept(this);
      n.f3.accept(this);
      return _ret;
   }

   /**
    * f0 -> "import"
    * f1 -> "java.util.function.Function"
    * f2 -> ";"
    */
   public R visit(ImportFunction n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      n.f2.accept(this);
      return _ret;
   }

   /**
    * f0 -> "class"
    * f1 -> Identifier()
    * f2 -> "{"
    * f3 -> "public"
    * f4 -> "static"
    * f5 -> "void"
    * f6 -> "main"
    * f7 -> "("
    * f8 -> "String"
    * f9 -> "["
    * f10 -> "]"
    * f11 -> Identifier()
    * f12 -> ")"
    * f13 -> "{"
    * f14 -> PrintStatement()
    * f15 -> "}"
    * f16 -> "}"
    */
   public R visit(MainClass n) {
      R _ret=null;
      n.f0.accept(this);
      curClass =  (String)n.f1.accept(this);
      curMethod = "main";
      n.f2.accept(this);
      n.f3.accept(this);
      n.f4.accept(this);
      n.f5.accept(this);
      n.f6.accept(this);
      n.f7.accept(this);
      n.f8.accept(this);
      n.f9.accept(this);
      n.f10.accept(this);
      n.f11.accept(this);
      n.f12.accept(this);
      n.f13.accept(this);
      n.f14.accept(this);
      n.f15.accept(this);
      n.f16.accept(this);
      return _ret;
   }

   /**
    * f0 -> ClassDeclaration()
    *       | ClassExtendsDeclaration()
    */
   public R visit(TypeDeclaration n) {
      R _ret=null;
      n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> "class"
    * f1 -> Identifier()
    * f2 -> "{"
    * f3 -> ( VarDeclaration() )*
    * f4 -> ( MethodDeclaration() )*
    * f5 -> "}"
    */
   public R visit(ClassDeclaration n) {
      R _ret=null;
      n.f0.accept(this);
      curClass = (String)n.f1.accept(this);
      n.f2.accept(this);
      n.f3.accept(this);
      n.f4.accept(this);
      n.f5.accept(this);
      return _ret;
   }

   /**
    * f0 -> "class"
    * f1 -> Identifier()
    * f2 -> "extends"
    * f3 -> Identifier()
    * f4 -> "{"
    * f5 -> ( VarDeclaration() )*
    * f6 -> ( MethodDeclaration() )*
    * f7 -> "}"
    */
   public R visit(ClassExtendsDeclaration n) {
      R _ret=null;
      n.f0.accept(this);
      curClass = (String)n.f1.accept(this);
      n.f2.accept(this);
      String parClass = (String)n.f3.accept(this);
      if(classes.get(parClass) == null)SymbolNotFound();
      n.f4.accept(this);
      n.f5.accept(this);
      n.f6.accept(this);
      n.f7.accept(this);
      return _ret;
   }

   /**
    * f0 -> Type()
    * f1 -> Identifier()
    * f2 -> ";"
    */
   public R visit(VarDeclaration n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      n.f2.accept(this);
      return _ret;
   }

   /**
    * f0 -> "public"
    * f1 -> Type()
    * f2 -> Identifier()
    * f3 -> "("
    * f4 -> ( FormalParameterList() )?
    * f5 -> ")"
    * f6 -> "{"
    * f7 -> ( VarDeclaration() )*
    * f8 -> ( Statement() )*
    * f9 -> "return"
    * f10 -> Expression()
    * f11 -> ";"
    * f12 -> "}"
    */
   public R visit(MethodDeclaration n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      curMethod = (String)n.f2.accept(this);
      n.f3.accept(this);
      n.f4.accept(this);
      n.f5.accept(this);
      n.f6.accept(this);
      n.f7.accept(this);
      n.f8.accept(this);
      n.f9.accept(this);
      String type1 = classes.get(curClass).methods.get(curMethod).type;
      if(type1.contains("#")){
         String[] puts = type1.split("#");
         LamdaArg = puts[0];
      }
      String returnType2 = (String)n.f10.accept(this);
      LamdaArg = null;
      n.f11.accept(this);
      n.f12.accept(this);
      if(!type1.equals(returnType2))typeError();
      return _ret;
   }

   /**
    * f0 -> FormalParameter()
    * f1 -> ( FormalParameterRest() )*
    */
   public R visit(FormalParameterList n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      return _ret;
   }

   /**
    * f0 -> Type()
    * f1 -> Identifier()
    */
   public R visit(FormalParameter n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      return _ret;
   }

   /**
    * f0 -> ","
    * f1 -> FormalParameter()
    */
   public R visit(FormalParameterRest n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      return _ret;
   }

   /**
    * f0 -> ArrayType()
    *       | BooleanType()
    *       | IntegerType()
    *       | Identifier()
    *       | LambdaType()
    */
   public R visit(Type n) {
      R _ret = null;
      n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> "int"
    * f1 -> "["
    * f2 -> "]"
    */
   public R visit(ArrayType n) {
      R _ret = null;
      n.f0.accept(this);
      n.f1.accept(this);
      n.f2.accept(this);
      return _ret;
   }

   /**
    * f0 -> "boolean"
    */
   public R visit(BooleanType n) {
      R _ret = null;
      n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> "int"
    */
   public R visit(IntegerType n) {
      R _ret = null;
      n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> "Function"
    * f1 -> "<"
    * f2 -> Identifier()
    * f3 -> ","
    * f4 -> Identifier()
    * f5 -> ">"
    */
   public R visit(LambdaType n) {
      R _ret = null;
      n.f0.accept(this);
      n.f1.accept(this);
      n.f2.accept(this);
      n.f3.accept(this);
      n.f4.accept(this);
      n.f5.accept(this);
      return _ret;
   }

   /**
    * f0 -> Block()
    *       | AssignmentStatement()
    *       | ArrayAssignmentStatement()
    *       | IfStatement()
    *       | WhileStatement()
    *       | PrintStatement()
    */
   public R visit(Statement n) {
      R _ret=null;
      n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> "{"
    * f1 -> ( Statement() )*
    * f2 -> "}"
    */
   public R visit(Block n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      n.f2.accept(this);
      return _ret;
   }

   /**
    * f0 -> Identifier()
    * f1 -> "="
    * f2 -> Expression()
    * f3 -> ";"
    */
   public R visit(AssignmentStatement n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      if(type1.contains("#")){
         String[] puts = type1.split("#");
         LamdaArg = puts[0];
      }
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      n.f3.accept(this);
      // System.out.println(type1 + " " + type2);
      if(classes.get(type1) != null && classes.get(type2) != null){
         // System.out.println(n.f0.f0.beginLine + " " + n.f0.f0.beginColumn);
         // System.out.println(type1 + " " + type2);
         if(!Path(type2, type1))typeError();
      }
      else if(classes.get(type1) == null && classes.get(type2) == null){
         // System.out.println(type1 + " " + type2);
         if(!type1.equals(type2))typeError();
      }
      else{
         typeError();
      }
      LamdaArg = null;
      return _ret;
   }

   /**
    * f0 -> Identifier()
    * f1 -> "["
    * f2 -> Expression()
    * f3 -> "]"
    * f4 -> "="
    * f5 -> Expression()
    * f6 -> ";"
    */
   public R visit(ArrayAssignmentStatement n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      n.f3.accept(this);
      n.f4.accept(this);
      String type3 = (String)n.f5.accept(this);
      n.f6.accept(this);
      if(!type1.equals("int[]") || !type2.equals("int") || !type3.equals("int"))typeError();
      return _ret;
   }

   /**
    * f0 -> IfthenElseStatement()
    *       | IfthenStatement()
    */
   public R visit(IfStatement n) {
      R _ret=null;
      n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> "if"
    * f1 -> "("
    * f2 -> Expression()
    * f3 -> ")"
    * f4 -> Statement()
    */
   public R visit(IfthenStatement n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      String type1 = (String)n.f2.accept(this);
      if(!type1.equals("boolean"))typeError();
      n.f3.accept(this);
      n.f4.accept(this);
      return _ret;
   }

   /**
    * f0 -> "if"
    * f1 -> "("
    * f2 -> Expression()
    * f3 -> ")"
    * f4 -> Statement()
    * f5 -> "else"
    * f6 -> Statement()
    */
   public R visit(IfthenElseStatement n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      String type1 = (String)n.f2.accept(this);
      if(!type1.equals("boolean"))typeError();
      n.f3.accept(this);
      n.f4.accept(this);
      n.f5.accept(this);
      n.f6.accept(this);
      return _ret;
   }

   /**
    * f0 -> "while"
    * f1 -> "("
    * f2 -> Expression()
    * f3 -> ")"
    * f4 -> Statement()
    */
   public R visit(WhileStatement n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      String type1 = (String)n.f2.accept(this);
      if(type1 != "boolean")typeError();
      n.f3.accept(this);
      n.f4.accept(this);
      return _ret;
   }

   /**
    * f0 -> "System.out.println"
    * f1 -> "("
    * f2 -> Expression()
    * f3 -> ")"
    * f4 -> ";"
    */
   public R visit(PrintStatement n) {
      R _ret=null;
      n.f0.accept(this);
      n.f1.accept(this);
      String type = (String)n.f2.accept(this);
      if(!type.equals("int"))typeError();
      n.f3.accept(this);
      n.f4.accept(this);
      return _ret;
   }

   /**
    * f0 -> OrExpression()
    *       | AndExpression()
    *       | CompareExpression()
    *       | neqExpression()
    *       | AddExpression()
    *       | MinusExpression()
    *       | TimesExpression()
    *       | DivExpression()
    *       | ArrayLookup()
    *       | ArrayLength()
    *       | MessageSend()
    *       | LambdaExpression()
    *       | PrimaryExpression()
    */
   public R visit(Expression n) {
      R _ret = n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> "("
    * f1 -> Identifier()
    * f2 -> ")"
    * f3 -> "->"
    * f4 -> Expression()
    */
   public R visit(LambdaExpression n) {
      R _ret=null;
      n.f0.accept(this);
      inLamda = true;
      String type1 = (String)n.f1.accept(this);
      inLamda = false;
      n.f2.accept(this);
      n.f3.accept(this);
      String type2 = (String)n.f4.accept(this);
      LamdaLocal.clear();
      _ret = (R)(type1 + "#" + type2);
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "&&"
    * f2 -> PrimaryExpression()
    */
   public R visit(AndExpression n) {
      R _ret = null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      if(type1.equals("boolean") && type2.equals("boolean")){
         _ret = (R)"boolean";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "||"
    * f2 -> PrimaryExpression()
    */
   public R visit(OrExpression n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      if(type1.equals("boolean") && type2.equals("boolean")){
         _ret = (R)"boolean";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "<="
    * f2 -> PrimaryExpression()
    */
   public R visit(CompareExpression n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      if(type1.equals("int") && type2.equals("int")){
         _ret = (R)"boolean";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "!="
    * f2 -> PrimaryExpression()
    */
   public R visit(neqExpression n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      if((type1.equals("int") && type2.equals("int")) || (type1.equals("boolean") && type2.equals("boolean"))){
         _ret = (R)"boolean";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "+"
    * f2 -> PrimaryExpression()
    */
   public R visit(AddExpression n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      if(type1.equals("int") && type2.equals("int")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "-"
    * f2 -> PrimaryExpression()
    */
   public R visit(MinusExpression n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      if(type1.equals("int") && type2.equals("int")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "*"
    * f2 -> PrimaryExpression()
    */
   public R visit(TimesExpression n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      if(type1.equals("int") && type2.equals("int")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "/"
    * f2 -> PrimaryExpression()
    */
   public R visit(DivExpression n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      if(type1.equals("int") && type2.equals("int")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "["
    * f2 -> PrimaryExpression()
    * f3 -> "]"
    */
   public R visit(ArrayLookup n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      String type2 = (String)n.f2.accept(this);
      n.f3.accept(this);
      if(type1.equals("int[]") && type2.equals("int")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "."
    * f2 -> "length"
    */
   public R visit(ArrayLength n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      n.f1.accept(this);
      n.f2.accept(this);
      if(type1.equals("int[]")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "."
    * f2 -> Identifier()
    * f3 -> "("
    * f4 -> ( ExpressionList() )?
    * f5 -> ")"
    */
   public R visit(MessageSend n) {
      R _ret=null;
      accessClass = (String)n.f0.accept(this);
      n.f1.accept(this);
      String returnType = accessClass;
      if(returnType.contains("#")){
         String[] puts = returnType.split("#");
         String func = (String)n.f2.accept(this);
         if(!func.equals("apply"))SymbolNotFound();
         n.f3.accept(this);
         String args = (String)n.f4.accept(this);
         if(args == null || args.contains(",") || !puts[0].equals(args))typeError();
         n.f5.accept(this);
         return (R)puts[1];
      }
      accessing = true;
      String method1 = (String)n.f2.accept(this);
      accessing = false;
      _ret = (R)method1;
      n.f3.accept(this);
      String arg2 = accessClass, arg3 = accessMethod;
      String args = (String)n.f4.accept(this);
      CheckArgs(args, arg2, arg3);
      n.f5.accept(this);
      return _ret;
   }

   /**
    * f0 -> Expression()
    * f1 -> ( ExpressionRest() )*
    */
   public R visit(ExpressionList n) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this);
      String type2 = (String)n.f1.accept(this);
      if(type2 != null)_ret = (R)(type1 + type2);
      else _ret = (R)type1;
      return _ret;
   }

   /**
    * f0 -> ","
    * f1 -> Expression()
    */
   public R visit(ExpressionRest n) {
      R _ret=null;
      n.f0.accept(this);
      String type = (String)n.f1.accept(this);
      _ret = (R)("," + type);
      return _ret;
   }

   /**
    * f0 -> IntegerLiteral()
    *       | TrueLiteral()
    *       | FalseLiteral()
    *       | Identifier()
    *       | ThisExpression()
    *       | ArrayAllocationExpression()
    *       | AllocationExpression()
    *       | NotExpression()
    *       | BracketExpression()
    */
   public R visit(PrimaryExpression n) {
      R _ret = n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> <INTEGER_LITERAL>
    */
   public R visit(IntegerLiteral n) {
      R _ret = (R)"int";
      n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> "true"
    */
   public R visit(TrueLiteral n) {
      R _ret = (R)"boolean";
      n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> "false"
    */
   public R visit(FalseLiteral n) {
      R _ret = (R)"boolean";
      n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> <IDENTIFIER>
    */
   public R visit(Identifier n) {
      R _ret = null;
      String id = (String)n.f0.accept(this);
      if(accessing){
         accessMethod = id;
         String cur = accessClass;
         while(cur != null){
            if(classes.get(cur).methods.get(id) != null){
               _ret = (R)classes.get(accessClass).methods.get(id).type;
               break;
            }
            cur = classes.get(cur).par;
         }
      }
      else if(inLamda){
         LamdaLocal.put(id, LamdaArg);
         _ret = (R)LamdaArg;
      }
      else _ret = (R)findVarLoop(id);
      return _ret;
   }

   /**
    * f0 -> "this"
    */
   public R visit(ThisExpression n) {
      R _ret = (R)curClass;
      n.f0.accept(this);
      return _ret;
   }

   /**
    * f0 -> "new"
    * f1 -> "int"
    * f2 -> "["
    * f3 -> Expression()
    * f4 -> "]"
    */
   public R visit(ArrayAllocationExpression n) {
      R _ret = null;
      n.f0.accept(this);
      n.f1.accept(this);
      n.f2.accept(this);
      String type1 = (String)n.f3.accept(this);
      if(type1.equals("int")){
         _ret = (R)"int[]";
      }
      else{
         typeError();
      }
      n.f4.accept(this);
      return _ret;
   }

   /**
    * f0 -> "new"
    * f1 -> Identifier()
    * f2 -> "("
    * f3 -> ")"
    */
   public R visit(AllocationExpression n) {
      R _ret=null;
      n.f0.accept(this);
      String class1 = (String)n.f1.accept(this);
      ClassExists(class1);
      _ret = (R)class1;
      n.f2.accept(this);
      n.f3.accept(this);
      return _ret;
   }

   /**
    * f0 -> "!"
    * f1 -> Expression()
    */
   public R visit(NotExpression n) {
      R _ret=null;
      n.f0.accept(this);
      String type1 = (String)n.f1.accept(this);
      if(type1.equals("boolean")){
         _ret = (R)"boolean";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> "("
    * f1 -> Expression()
    * f2 -> ")"
    */
   public R visit(BracketExpression n) {
      R _ret=null;
      n.f0.accept(this);
      _ret = n.f1.accept(this);
      n.f2.accept(this);
      return _ret;
   }

}
