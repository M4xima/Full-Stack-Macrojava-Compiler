package visitor;

import java.util.HashMap;
import java.util.Map;

public class ClassObj{
    public String name;
    public Map<String, String> cAttributes;
    public Map<String, MethodObj> methods;
    public String par;
    public ClassObj(String name1) {
        name = name1;
        cAttributes = new HashMap<>();
        methods = new HashMap<>();
        par = null;
    }
    public ClassObj(String name1, String par1) {
        name = name1;
        cAttributes = new HashMap<>();
        methods = new HashMap<>();
        par = par1;
    }
}