package visitor;
import java.text.ParseException;
import java.util.*;

import javax.print.PrintException;
import javax.swing.UIManager.LookAndFeelInfo;

import syntaxtree.*;

/**
 * Provides default methods which visit each node in the tree in depth-first
 * order.  Your visitors may extend this class.
 */
public class GJDepthFirst<R,A> implements GJVisitor<R,A> {
   //
   // Auto class visitors--probably don't need to be overridden.
   //
   String curClass = "NoClassYet";
   String curMethod = "NoMethodYet";
   // boolean accessing = false;
   boolean inLamda = false;
   boolean inIf = false;
   String accessClass = "NoClassYet";
   String accessMethod = "NoMethodYet";
   String LamdaArg = null;
   Map<String, ClassObj> classes;
   Map<String, String> LamdaLocal = new HashMap<>();
   Map<String, String> Wrapper = new HashMap<>();
   String curArgs = null;
   public GJDepthFirst(Map<String, ClassObj> classes1){
      classes = classes1;
      Wrapper.put("Integer", "int");
      Wrapper.put("Boolean", "boolean");
   }
   public void typeError() throws MyException {
      throw new MyException("Type error");
   }
   public void SymbolNotFound() throws MyException {
      throw new MyException("Symbol not found");
   }
   public String findVar(String var, String cur){
      if(classes.get(var) != null)return var;
      // //debugging start
      // ClassObj c = classes.get(cur);
      // if (c == null) {
      //    throw new MyException("Class " + cur + " not declared");
      // }
      // //debugging end
      if(classes.get(cur).methods.get(var) != null)return var;
      if(Wrapper.get(var) != null)return Wrapper.get(var);
      if(LamdaLocal.get(var) != null)return LamdaLocal.get(var);
      MethodObj methodname = classes.get(cur).methods.get(curMethod);
      if(methodname != null){
         String inmethod = methodname.mAttributes.get(var);
         if(inmethod != null)return inmethod;
         for (List<String> argList :methodname.arguments) {
            if(argList.get(0).equals(var))return argList.get(1);
         };
      }   
      String inclass = classes.get(cur).cAttributes.get(var);
      if(inclass != null)return inclass;
      // System.out.println("Symbol not found -> " + var);
      // SymbolNotFound();
      return null;
   }
   public String findVarLoop(String var){
      // System.out.println(var);
      String cur = curClass;
      String temp = findVar(var, cur);
      if(temp != null)return temp;
      cur = classes.get(cur).par;
      while(cur != null){
         String inclass = classes.get(cur).cAttributes.get(var);
         if(inclass != null)return inclass;
         // System.out.println("Inloop before cur = " + cur);
         cur = classes.get(cur).par;
         // System.out.println("Inloop after cur = " + cur);
      }
      // System.out.println("Symbol not found -> " + var);
      SymbolNotFound();
      return null;
   }
   public void ClassExists(String class1){
      if(classes.get(class1) == null)SymbolNotFound();
   }
   public void PlaceMethodParam(String var){
      classes.get(curClass).methods.get(curMethod).arguments.size();
   }
   public boolean Path(String child,String par){
      String cur = child;
      while(cur != null){
         if(cur.equals(par))return true;
         cur = classes.get(cur).par;
      }
      return false;
   }
   public R visit(NodeList n, A argu) {
      R _ret = null;
      int _count=0;
      for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
         e.nextElement().accept(this, argu);
         _count++;
      }
      return _ret;
   }

   public R visit(NodeListOptional n, A argu) {
      if ( n.present() ) {
         int _count=0;
         for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) { 
            e.nextElement().accept(this, (A)argu);
            _count++;
         }
         return null;
      }
      else
         return null;
   }

   public R visit(NodeOptional n, A argu) {
      if ( n.present() )
         return n.node.accept(this, argu);
      else
         return null;
   }

   public R visit(NodeSequence n, A argu) {
      R _ret=null;
      int _count=0;
      for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
         e.nextElement().accept(this, argu);
         _count++;
      }
      return _ret;
   }

   public R visit(NodeToken n, A argu) { return (R)n.tokenImage; }

   //
   // User-generated visitor methods below
   //

   /**
    * f0 -> ( ImportFunction() )?
    * f1 -> MainClass()
    * f2 -> ( TypeDeclaration() )*
    * f3 -> <EOF>
    */
   public R visit(Goal n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "import"
    * f1 -> "java.util.function.Function"
    * f2 -> ";"
    */
   public R visit(ImportFunction n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "class"
    * f1 -> Identifier()
    * f2 -> "{"
    * f3 -> "public"
    * f4 -> "static"
    * f5 -> "void"
    * f6 -> "main"
    * f7 -> "("
    * f8 -> "String"
    * f9 -> "["
    * f10 -> "]"
    * f11 -> Identifier()
    * f12 -> ")"
    * f13 -> "{"
    * f14 -> PrintStatement()
    * f15 -> "}"
    * f16 -> "}"
    */
   public R visit(MainClass n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      curClass =  (String)n.f1.accept(this, argu);
      curMethod = "main";
      n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      n.f4.accept(this, argu);
      n.f5.accept(this, argu);
      n.f6.accept(this, argu);
      n.f7.accept(this, argu);
      n.f8.accept(this, argu);
      n.f9.accept(this, argu);
      n.f10.accept(this, argu);
      n.f11.accept(this, argu);
      n.f12.accept(this, argu);
      n.f13.accept(this, argu);
      n.f14.accept(this, argu);
      n.f15.accept(this, argu);
      n.f16.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> ClassDeclaration()
    *       | ClassExtendsDeclaration()
    */
   public R visit(TypeDeclaration n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "class"
    * f1 -> Identifier()
    * f2 -> "{"
    * f3 -> ( VarDeclaration() )*
    * f4 -> ( MethodDeclaration() )*
    * f5 -> "}"
    */
   public R visit(ClassDeclaration n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      curClass = (String)n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      n.f4.accept(this, argu);
      n.f5.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "class"
    * f1 -> Identifier()
    * f2 -> "extends"
    * f3 -> Identifier()
    * f4 -> "{"
    * f5 -> ( VarDeclaration() )*
    * f6 -> ( MethodDeclaration() )*
    * f7 -> "}"
    */
   public R visit(ClassExtendsDeclaration n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      curClass = (String)n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      String parClass = (String)n.f3.accept(this, argu);
      if(classes.get(parClass) == null)SymbolNotFound();
      n.f4.accept(this, argu);
      n.f5.accept(this, argu);
      n.f6.accept(this, argu);
      n.f7.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> Type()
    * f1 -> Identifier()
    * f2 -> ";"
    */
   public R visit(VarDeclaration n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "public"
    * f1 -> Type()
    * f2 -> Identifier()
    * f3 -> "("
    * f4 -> ( FormalParameterList() )?
    * f5 -> ")"
    * f6 -> "{"
    * f7 -> ( VarDeclaration() )*
    * f8 -> ( Statement() )*
    * f9 -> "return"
    * f10 -> Expression()
    * f11 -> ";"
    * f12 -> "}"
    */
   public R visit(MethodDeclaration n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      curMethod = (String)n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      n.f4.accept(this, argu);
      n.f5.accept(this, argu);
      n.f6.accept(this, argu);
      n.f7.accept(this, argu);
      n.f8.accept(this, argu);
      n.f9.accept(this, argu);
      String type1 = classes.get(curClass).methods.get(curMethod).type;
      if(type1.contains("#")){
         String[] puts = type1.split("#");
         LamdaArg = puts[0];
      }
      String returnType2 = (String)n.f10.accept(this, argu);
      LamdaArg = null;
      n.f11.accept(this, argu);
      n.f12.accept(this, argu);
      if(!type1.equals(returnType2))typeError();
      return _ret;
   }

   /**
    * f0 -> FormalParameter()
    * f1 -> ( FormalParameterRest() )*
    */
   public R visit(FormalParameterList n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> Type()
    * f1 -> Identifier()
    */
   public R visit(FormalParameter n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> ","
    * f1 -> FormalParameter()
    */
   public R visit(FormalParameterRest n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> ArrayType()
    *       | BooleanType()
    *       | IntegerType()
    *       | Identifier()
    *       | LambdaType()
    */
   public R visit(Type n, A argu) {
      R _ret = null;
      n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "int"
    * f1 -> "["
    * f2 -> "]"
    */
   public R visit(ArrayType n, A argu) {
      R _ret = null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "boolean"
    */
   public R visit(BooleanType n, A argu) {
      R _ret = null;
      n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "int"
    */
   public R visit(IntegerType n, A argu) {
      R _ret = null;
      n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "Function"
    * f1 -> "<"
    * f2 -> Identifier()
    * f3 -> ","
    * f4 -> Identifier()
    * f5 -> ">"
    */
   public R visit(LambdaType n, A argu) {
      R _ret = null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      n.f4.accept(this, argu);
      n.f5.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> Block()
    *       | AssignmentStatement()
    *       | ArrayAssignmentStatement()
    *       | IfStatement()
    *       | WhileStatement()
    *       | PrintStatement()
    */
   public R visit(Statement n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "{"
    * f1 -> ( Statement() )*
    * f2 -> "}"
    */
   public R visit(Block n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> Identifier()
    * f1 -> "="
    * f2 -> Expression()
    * f3 -> ";"
    */
   public R visit(AssignmentStatement n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      if(type1.contains("#")){
         String[] puts = type1.split("#");
         LamdaArg = puts[0];
      }
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      // System.out.println(type1 + " " + type2);
      if(classes.get(type1) != null && classes.get(type2) != null){
         // System.out.println(n.f0.f0.beginLine + " " + n.f0.f0.beginColumn);
         // System.out.println(type1 + " " + type2);
         if(!Path(type2, type1))typeError();
      }
      else if(classes.get(type1) == null && classes.get(type2) == null){
         // System.out.println(type1 + " " + type2);
         if(!type1.equals(type2))typeError();
      }
      else{
         typeError();
      }
      LamdaArg = null;
      return _ret;
   }

   /**
    * f0 -> Identifier()
    * f1 -> "["
    * f2 -> Expression()
    * f3 -> "]"
    * f4 -> "="
    * f5 -> Expression()
    * f6 -> ";"
    */
   public R visit(ArrayAssignmentStatement n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      n.f4.accept(this, argu);
      String type3 = (String)n.f5.accept(this, argu);
      n.f6.accept(this, argu);
      if(!type1.equals("int[]") || !type2.equals("int") || !type3.equals("int"))typeError();
      return _ret;
   }

   /**
    * f0 -> IfthenElseStatement()
    *       | IfthenStatement()
    */
   public R visit(IfStatement n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "if"
    * f1 -> "("
    * f2 -> Expression()
    * f3 -> ")"
    * f4 -> Statement()
    */
   public R visit(IfthenStatement n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      inIf = true;
      String type1 = (String)n.f2.accept(this, argu);
      if(!type1.equals("boolean"))typeError();
      inIf = false;
      n.f3.accept(this, argu);
      n.f4.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "if"
    * f1 -> "("
    * f2 -> Expression()
    * f3 -> ")"
    * f4 -> Statement()
    * f5 -> "else"
    * f6 -> Statement()
    */
   public R visit(IfthenElseStatement n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      inIf = true;
      String type1 = (String)n.f2.accept(this, argu);
      if(!type1.equals("boolean"))typeError();
      inIf = false;
      n.f3.accept(this, argu);
      n.f4.accept(this, argu);
      n.f5.accept(this, argu);
      n.f6.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "while"
    * f1 -> "("
    * f2 -> Expression()
    * f3 -> ")"
    * f4 -> Statement()
    */
   public R visit(WhileStatement n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      inIf = true;
      String type1 = (String)n.f2.accept(this, argu);
      if(type1 != "boolean")typeError();
      inIf = false;
      n.f3.accept(this, argu);
      n.f4.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "System.out.println"
    * f1 -> "("
    * f2 -> Expression()
    * f3 -> ")"
    * f4 -> ";"
    */
   public R visit(PrintStatement n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type = (String)n.f2.accept(this, argu);
      if(!type.equals("int"))typeError();
      n.f3.accept(this, argu);
      n.f4.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> OrExpression()
    *       | AndExpression()
    *       | CompareExpression()
    *       | neqExpression()
    *       | AddExpression()
    *       | MinusExpression()
    *       | TimesExpression()
    *       | DivExpression()
    *       | ArrayLookup()
    *       | ArrayLength()
    *       | MessageSend()
    *       | LambdaExpression()
    *       | PrimaryExpression()
    */
   public R visit(Expression n, A argu) {
      R _ret = n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "("
    * f1 -> Identifier()
    * f2 -> ")"
    * f3 -> "->"
    * f4 -> Expression()
    */
   public R visit(LambdaExpression n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      inLamda = true;
      String type1 = (String)n.f1.accept(this, argu);
      inLamda = false;
      n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      String type2 = (String)n.f4.accept(this, argu);
      LamdaLocal.clear();
      _ret = (R)(type1 + "#" + type2);
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "&&"
    * f2 -> PrimaryExpression()
    */
   public R visit(AndExpression n, A argu) {
      R _ret = null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      if(type1.equals("boolean") && type2.equals("boolean")){
         _ret = (R)"boolean";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "||"
    * f2 -> PrimaryExpression()
    */
   public R visit(OrExpression n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      if(type1.equals("boolean") && type2.equals("boolean")){
         _ret = (R)"boolean";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "<="
    * f2 -> PrimaryExpression()
    */
   public R visit(CompareExpression n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      if(type1.equals("int") && type2.equals("int")){
         _ret = (R)"boolean";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "!="
    * f2 -> PrimaryExpression()
    */
   public R visit(neqExpression n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      if((type1.equals("int") && type2.equals("int")) || (type1.equals("boolean") && type2.equals("boolean"))){
         _ret = (R)"boolean";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "+"
    * f2 -> PrimaryExpression()
    */
   public R visit(AddExpression n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      if(type1.equals("int") && type2.equals("int")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "-"
    * f2 -> PrimaryExpression()
    */
   public R visit(MinusExpression n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      if(type1.equals("int") && type2.equals("int")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "*"
    * f2 -> PrimaryExpression()
    */
   public R visit(TimesExpression n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      if(type1.equals("int") && type2.equals("int")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "/"
    * f2 -> PrimaryExpression()
    */
   public R visit(DivExpression n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      if(type1.equals("int") && type2.equals("int")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "["
    * f2 -> PrimaryExpression()
    * f3 -> "]"
    */
   public R visit(ArrayLookup n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String type2 = (String)n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      if(type1.equals("int[]") && type2.equals("int")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "."
    * f2 -> "length"
    */
   public R visit(ArrayLength n, A argu) {
      R _ret=null;
      String type1 = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      if(type1.equals("int[]")){
         _ret = (R)"int";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> PrimaryExpression()
    * f1 -> "."
    * f2 -> Identifier()
    * f3 -> "("
    * f4 -> ( ExpressionList() )?
    * f5 -> ")"
    */
   public R visit(MessageSend n, A argu) {
      R _ret=null;
      accessClass = (String)n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      String returnType = accessClass;
      if(returnType.contains("#")){
         String[] puts = returnType.split("#");
         String func = (String)n.f2.accept(this, argu);
         if(!func.equals("apply"))SymbolNotFound();
         n.f3.accept(this, argu);
         String args = (String)n.f4.accept(this, argu);
         if(args == null || args.contains(",") || !puts[0].equals(args))typeError();
         n.f5.accept(this, argu);
         return (R)puts[1];
      }
      String method1 = (String)n.f2.accept(this, (A)"1");
      _ret = (R)method1;
      n.f3.accept(this, argu);
      // String arg2 = accessClass, arg3 = accessMethod;
      List<List<String>> args2 = classes.get(accessClass).methods.get(accessMethod).arguments;
      String args = null;
      if(args2.size() > 0)args = args2.get(0).get(1);
      for (int i = 1;i < args2.size();i ++) {
         args += "," + args2.get(i).get(1);
      }
      curArgs = args;
      // System.out.println(args);
      n.f4.accept(this, (A)args);
      n.f5.accept(this, argu);
      if(curArgs != null)SymbolNotFound();
      return _ret;
   }

   /**
    * f0 -> Expression()
    * f1 -> ( ExpressionRest() )*
    */
   public R visit(ExpressionList n, A argu) {
      R _ret=null;
      String[] args = ((String)argu).split(",", 2);
      if(args[0].contains("#")){
         String[] puts = args[0].split("#");
         LamdaArg = puts[0];
      }
      String type1 = (String)n.f0.accept(this, argu);
      if(!Path(type1, args[0]))typeError();
      LamdaArg = null;
      if(args.length == 1)curArgs = null;
      else curArgs = args[1];
      n.f1.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> ","
    * f1 -> Expression()
    */
   public R visit(ExpressionRest n, A argu) {
      R _ret=null;
      if(curArgs == null)SymbolNotFound();
      n.f0.accept(this, argu);
      String[] args = curArgs.split(",", 2);
      if(args[0].contains("#")){
         String[] puts = ((String)args[0]).split("#");
         LamdaArg = puts[0];
      }
      String type1 = (String)n.f1.accept(this, argu);
      if(!Path(type1, args[0]))typeError();
      LamdaArg = null;
      if(args.length == 1)curArgs = null;
      else curArgs = args[1];
      return _ret;
   }

   /**
    * f0 -> IntegerLiteral()
    *       | TrueLiteral()
    *       | FalseLiteral()
    *       | Identifier()
    *       | ThisExpression()
    *       | ArrayAllocationExpression()
    *       | AllocationExpression()
    *       | NotExpression()
    *       | BracketExpression()
    */
   public R visit(PrimaryExpression n, A argu) {
      R _ret = n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> <INTEGER_LITERAL>
    */
   public R visit(IntegerLiteral n, A argu) {
      R _ret = (R)"int";
      n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "true"
    */
   public R visit(TrueLiteral n, A argu) {
      R _ret = (R)"boolean";
      n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "false"
    */
   public R visit(FalseLiteral n, A argu) {
      R _ret = (R)"boolean";
      n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> <IDENTIFIER>
    */
   public R visit(Identifier n, A accessing) {
      R _ret = null;
      String id = (String)n.f0.accept(this, (A)"0");
      if(accessing.equals("1")){
         accessMethod = id;
         String cur = accessClass;
         while(cur != null){
            if(classes.get(cur).methods.get(id) != null){
               _ret = (R)classes.get(accessClass).methods.get(id).type;
               break;
            }
            cur = classes.get(cur).par;
         }
      }
      else if(inLamda){
         if(LamdaArg == null)typeError();
         LamdaLocal.put(id, LamdaArg);
         _ret = (R)LamdaArg;
      }
      else _ret = (R)findVarLoop(id);
      return _ret;
   }

   /**
    * f0 -> "this"
    */
   public R visit(ThisExpression n, A argu) {
      R _ret = (R)curClass;
      n.f0.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "new"
    * f1 -> "int"
    * f2 -> "["
    * f3 -> Expression()
    * f4 -> "]"
    */
   public R visit(ArrayAllocationExpression n, A argu) {
      R _ret = null;
      n.f0.accept(this, argu);
      n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      String type1 = (String)n.f3.accept(this, argu);
      if(type1.equals("int")){
         _ret = (R)"int[]";
      }
      else{
         typeError();
      }
      n.f4.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "new"
    * f1 -> Identifier()
    * f2 -> "("
    * f3 -> ")"
    */
   public R visit(AllocationExpression n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      String class1 = (String)n.f1.accept(this, argu);
      // ClassExists(class1);
      if(classes.get(class1) == null)SymbolNotFound();
      _ret = (R)class1;
      n.f2.accept(this, argu);
      n.f3.accept(this, argu);
      return _ret;
   }

   /**
    * f0 -> "!"
    * f1 -> Expression()
    */
   public R visit(NotExpression n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      String type1 = (String)n.f1.accept(this, argu);
      if(type1.equals("boolean")){
         _ret = (R)"boolean";
      }
      else{
         typeError();
      }
      return _ret;
   }

   /**
    * f0 -> "("
    * f1 -> Expression()
    * f2 -> ")"
    */
   public R visit(BracketExpression n, A argu) {
      R _ret=null;
      n.f0.accept(this, argu);
      _ret = n.f1.accept(this, argu);
      n.f2.accept(this, argu);
      return _ret;
   }

}
