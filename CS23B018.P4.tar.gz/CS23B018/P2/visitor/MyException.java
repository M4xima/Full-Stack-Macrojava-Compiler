package visitor;

public class MyException extends RuntimeException {
    public MyException(String msg) {
        super(msg);
    }
}
