package visitor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MethodObj{
    public String type;
    public List<List<String>> arguments;
    public Map<String, String> mAttributes;
    public MethodObj(String s) {
        type = s;
        arguments = new ArrayList<>();
        mAttributes = new HashMap<>();
    }
}