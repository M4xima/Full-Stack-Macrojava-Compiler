package visitor;

import java.util.HashMap;
import java.util.Map;

public class LambdaObj {
    public Map<String, Integer> Attributes;
    public String applyFnContent;
    LambdaObj(){
        Attributes = new HashMap<>();
        applyFnContent = null;
    }
}
