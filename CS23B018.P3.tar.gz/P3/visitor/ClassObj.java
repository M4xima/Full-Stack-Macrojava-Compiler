package visitor;

import java.util.HashMap;
import java.util.Map;

public class ClassObj{
    public Map<String, String> cAttributes;
    public Map<String, String> AttriLabel;
    public Map<String, Integer> fieldAddr;

    public Map<String, String> MethodLabel;
    public Map<String, MethodObj> methods;
    public String par;
    public ClassObj() {
        cAttributes = new HashMap<>();
        AttriLabel = new HashMap<>();
        MethodLabel = new HashMap<>();
        fieldAddr = new HashMap<>();
        methods = new HashMap<>();
        par = null;
    }
    public ClassObj(String par1) {
        cAttributes = new HashMap<>();
        AttriLabel = new HashMap<>();
        MethodLabel = new HashMap<>();
        fieldAddr = new HashMap<>();
        methods = new HashMap<>();
        par = par1;
    }
    public ClassObj(ClassObj parent) {
        cAttributes = new HashMap<>(parent.cAttributes);
        AttriLabel = new HashMap<>(parent.AttriLabel);
        MethodLabel = new HashMap<>(parent.MethodLabel);
        fieldAddr = new HashMap<>(parent.fieldAddr);
        methods = new HashMap<>();
        for (Map.Entry<String, MethodObj> e : parent.methods.entrySet()) {
        methods.put(e.getKey(), new MethodObj(e.getValue())); 
        }
        par = parent.par;
    }
}