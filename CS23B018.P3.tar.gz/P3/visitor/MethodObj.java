package visitor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MethodObj{
    int methodAddr;
    int noofparam;
    public Map<String, Integer> mfieldAddr;
    public Map<String, String> AttriLabel;
    public Map<String, String> mAttributes;
    public MethodObj(int methodAddr1) {
        methodAddr = methodAddr1;
        mfieldAddr = new HashMap<>();
        mAttributes = new HashMap<>();
        AttriLabel = new HashMap<>();
    }
    public MethodObj(MethodObj other) {
        methodAddr = other.methodAddr;
        noofparam = other.noofparam;
        mfieldAddr = new HashMap<>(other.mfieldAddr);
        mAttributes = new HashMap<>(other.mAttributes);
        AttriLabel = new HashMap<>();
    }
}