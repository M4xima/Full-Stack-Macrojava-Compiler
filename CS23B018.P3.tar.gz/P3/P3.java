import syntaxtree.*;
import visitor.*;

public class P3 {
   public static void main(String [] args) {
      try {
         Node root = new MiniJavaParser(System.in).Goal();
         GJNoArguDepthFirst<String> parser1 = new GJNoArguDepthFirst<String>();
         root.accept(parser1); // Your assignment part is invoked here.
         GJDepthFirst<String, String> parser2 = new GJDepthFirst<String, String>(parser1.classes);
         root.accept(parser2, "0");
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
} 


